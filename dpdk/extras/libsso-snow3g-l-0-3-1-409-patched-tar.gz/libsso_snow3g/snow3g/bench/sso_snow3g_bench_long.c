/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_SNOW3G.L.0.3.1-409
*
***************************************************************************/

/*-----------------------------------------------------------------------
* Snow3g benchmark
*-----------------------------------------------------------------------
*
* A simple performance benchmark test for Snow3g.
*
*-----------------------------------------------------------------------*/
#ifdef IACA
#include <iacaMarks.h>
#endif  

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>

#include "sso_snow3g.h"
#include "sso_snow3g_internal.h"
#include "sso_common.h"
#include "sso_utils.h"

#define ITERATIONS 10000
#define MAXBUFS 16
#define MAX_DATA_LEN 2048


double get_processor_freq(void)
{
	struct timezone tzone;
	struct timeval tvstart, tvstop;
	uint64_t start, finish;
	uint64_t microsecs;
	memset(&tzone, 0, sizeof(tzone));
	
	gettimeofday(&tvstart, &tzone);
	start = sso_rdtsc();
	gettimeofday(&tvstart, &tzone);
	usleep(250000);
	gettimeofday(&tvstop, &tzone);
	finish = sso_rdtsc();
	gettimeofday(&tvstop, &tzone);
	microsecs = ((tvstop.tv_sec-tvstart.tv_sec)*1000000) + (tvstop.tv_usec-tvstart.tv_usec);
	
	return (double) (finish - start) / microsecs;
}


/***********************************************
* description:
*   This function generates len bytes of random data.
************************************************/
void genRandomData(uint8_t* pData, const uint32_t len) {
	
	uint32_t n;
	
	for(n = 0; n < len; n++) {
		pData[n] = (uint8_t)(rand() & 0xFF);
 	}
}

/***********************************************
* description:
*   This function creates test data to validate the f8_n function.
************************************************/
int createTestData(int ivLen, uint8_t *IV[MAXBUFS], uint8_t *pSrcData[MAXBUFS], uint8_t *pDstData[MAXBUFS])
{
	int i=0, status=0;
	
	for(i=0; i< MAXBUFS; i ++){

		IV[i] = (uint8_t *)malloc(ivLen);
		if(! IV[i]) {
			printf("malloc(IV[i]): failed ! \n");
			status =  1;
		}

		pSrcData[i] = (uint8_t*) malloc(MAX_DATA_LEN);
		if(! pSrcData[i]) {
			printf("malloc(pSrcData[i]): failed ! \n");
			status =  1;
		}
        pDstData[i] = (uint8_t*) malloc(MAX_DATA_LEN);
		if(! pDstData[i]) {
			printf("malloc(pDstData[i]): failed ! \n");
			status =  1;
		}

	}
	
	if(status) {
	
		for(i=0; i < MAXBUFS; i++) {

			if(pSrcData[i]) 
				free(pSrcData[i]);
            if(pDstData[i]) 
				free(pDstData[i]);

					
			if(IV[i])
				free(IV[i]);
		}
	}
	return status;
}

void freeTestData(uint8_t *IV[MAXBUFS], uint8_t *pSrcData[MAXBUFS], uint8_t *pDstData[MAXBUFS], int numPktSizes, int numBuffs) 
{
	int i=0;
	
	for(i=0; i < numPktSizes; i++) {
			free(pSrcData[i]);
            free(pDstData[i]);
			free(IV[i]);
	}
}

int main(int argc, char ** argv)
{
	int numBuffs=16, numPktSizes=0, i=0 , j=0,status,init = 0,rollover = 0;
	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	uint8_t* IV[MAXBUFS];
	uint8_t* pSrcData[MAXBUFS];
	uint8_t* pDstData[MAXBUFS];
	uint32_t packetLen[MAXBUFS];
	uint64_t  cpu_cycles=0, start=0, stop=0;
	/*Packet sizes to use in testing.*/
	uint32_t packetSizes[] = {40, 64, 80, 120, 240, 256, 400, 512, 600, 1024, 2048};
	numPktSizes=sizeof(packetSizes)/sizeof(uint32_t);
	unsigned long long cycleCount[numPktSizes];
	double Mbps=0;
	double cpufreq = get_processor_freq();
	time_t tsec = 0,dotspan;
	struct timeval startTime;
    	struct timezone ignore;
	double average[40 + 64 + 80 + 120 + 240 + 256 + 400 + 512 + 600 + 1024 + 2048];
	double spreads[40 + 64 + 80 + 120 + 240 + 256 + 400 + 512 + 600 + 1024 + 2048];
	char cpu_info[14];
	FILE* pipefp;

    printf("Parameters [buffers] [duration(hours)] [duration(min)]\n");
	if ( argc > 1 ) {
        numBuffs = atoi(argv[1]);
		if((numBuffs > 16) || (numBuffs == 0)) {
			printf("Incorrect number of buffers, using 16 ! \n");
			numBuffs = 16;
		}
        if ( argc > 2 ) {
             /* Test duration in Hours */
             tsec = atoi(argv[2]) * 60 * 60;
             if ( argc > 3 ) {
                 /* Extra test duration in  minutes */
                 tsec += atoi(argv[3]) * 60;
            }
        }
    } else { 
        i = sso_snow3g_cpuid_check();
        if(!(i & 1)) printf("SSE ") ; 	/*SSE:EDX:25*/	
        if(!(i & 2)) printf("SSE2 "); 	/*SSE2:EDX:26*/	
        if(!(i & 4)) printf("SSE3 "); 	/*SSE3:ECX:0*/	
        if(!(i & 8)) printf("SSE4.1 "); 	/*SSE4.1:ECX:19*/
        if(!(i & 0x10)) printf("SSE4.2 ");   /*SSE4.2:ECX:20*/
        if(!(i & 0x20)) printf("AVX "); 	/*AVX:ECX:28*/
        if(!(i & 0x40)) printf("PCMULQDQ"); 	/*PCMULQDQ:ECX:1 */	
        if(i != (0x1|0x2|0x4|0x8|0x10|0x20|0x40)) {
            printf(" not supported\n");
} else {
            printf("All flags supported\n");        }
        return 1;
    } 
    status = gettimeofday(&startTime,&ignore);
     if(status == -1){
        printf("Error: Couldn't get time of day\n");
        return 1;
     }
     dotspan = tsec;
     printf("Test will run %ld seconds\n",(long)tsec);
     tsec = tsec + startTime.tv_sec;
     memset(average,0,sizeof(double)*numPktSizes);
     do{

        pKey = malloc(SNOW3G_KEY_LEN_IN_BYTES);
        if(!pKey) {
            printf("malloc(pKey): failed ! \n");
            return 1;
         }
        genRandomData(pKey, SNOW3G_KEY_LEN_IN_BYTES);
        
        i = sso_snow3g_key_sched_size();
        if(!i) {
            free(pKey);
            return -1;
        }

        pKeySched = malloc(i);
        if (!pKeySched) {
            printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
            free(pKey);
            return 1;
        }
        if( sso_snow3g_init_key_sched(pKey, pKeySched)) {
            printf("sso_snow3g_init_f8_key_sched() error \n");
            free(pKey);
            return 1;
        }
        if(createTestData(SNOW3G_IV_LEN_IN_BYTES, IV, pSrcData, pDstData)) {
            printf("createTestData() error \n");
        } 

        fflush(stdout);

        /* calc the length of time it takes to get cpuid */
        cpu_cycles = get_cpuid_cycles();

        if (numBuffs == 1) {
            /* An initial run to warm up the cache */
            sso_snow3g_f8_1_buffer(pKeySched, IV[0], pSrcData[0], pSrcData[0], packetSizes[0]); 

             for(i=0;i < numPktSizes; i++) {
                cycleCount[i] = 0;
                memcpy(pDstData[i],pSrcData[i],packetSizes[i]);        
                start = sso_rdtscp(); 
                for(j=0; j < ITERATIONS; j++) {
                    sso_snow3g_f8_1_buffer(pKeySched, IV[i], pSrcData[i], pSrcData[i], packetSizes[i]); 
                }
                stop = sso_rdtscp(); 
                if (memcmp(pDstData[i],pSrcData[i],packetSizes[i]) != 0) {
                    printf("ERROR - data mismatch\n");
                    free(pKey);
                	freeTestData(IV, pSrcData, pDstData, numPktSizes, numBuffs);
                    return 1;
                }
                cycleCount[i] +=  (stop - start) - cpu_cycles; 
            }
        } else {
            for(i=0;i < numPktSizes; i++) {
                cycleCount[i] = 0;
                for(j=0; j< numBuffs; j++){
                    packetLen[j]= packetSizes[i];
                }
                /* An initial run to warm up the cache */
                sso_snow3g_f8_n_buffer(pKeySched, IV, pSrcData, pSrcData, packetLen, numBuffs); 
                for (j=0; j < numBuffs; j++) {
                    memcpy(pDstData[j],pSrcData[j],packetSizes[i]);        

                }
                start = sso_rdtscp(); 
                for(j=0; j < ITERATIONS; j++) {
                    sso_snow3g_f8_n_buffer(pKeySched, IV, pSrcData, pSrcData, packetLen, numBuffs); 
                }
                stop = sso_rdtscp();
                for(j=0; j < numBuffs; j++) {
                    if (memcmp(pDstData[j],pSrcData[j],packetSizes[i]) != 0) {
                        printf("ERROR - data mismatch\n");
                        free(pKey);
                        freeTestData(IV, pSrcData,pDstData, numPktSizes, numBuffs);
                        return 1;
                    }
                }
                cycleCount[i] +=  (stop - start) - cpu_cycles; 
            }
        }
       for(i=0;i < numPktSizes; i++) {
            double cycles =  (double) cycleCount[i]/ITERATIONS;
            //cycles per op	
            //cycles /= (packetSizes[i] * numBuffs);
            if (init == 0) {
                average[i] = cycles;
            } else {
                average[i] += (cycles - average[i]) * 0.05; 
            }
            spreads[i] = abs (cycles - average[i]);
            /* We can inseart boundary condition check for max spread */
        }
        gettimeofday(&startTime, &ignore);
        if ((init == 0) && (dotspan == 0)) {
            break;
        }
        init = 1;
        if ( startTime.tv_sec > dotspan ) {
            printf(".");
            fflush(stdout);
            dotspan = startTime.tv_sec + 60;
            
        }
        if (rollover) {
           if (startTime.tv_sec > tsec) {
                 continue;
           } else {
                  rollover = 0;
           }
        } else if ( startTime.tv_sec > tsec) {
            break;
        }
                                                                                         
    }while(1);
     printf("Waiting for CPU info.\n");
     if ((pipefp = popen("awk 'NR==5 {print $5 $7}' /proc/cpuinfo","r")) != NULL) {
        if (NULL == fgets(cpu_info,14,pipefp))    memcpy(cpu_info,"unknown",8);
	else        pclose(pipefp);
    } else {
        memcpy(cpu_info,"unknown",8);
    }

    printf("\nLibsso Snow3g f8 for %d packets @ %0.2f Hz. Cpu Model: %4.8s\n", numBuffs, cpufreq,cpu_info);
	printf("%s\t   %s\t  %s\t%s\t   %s\t    %s\n", "Bytes", "Cy/Op","average","spread","Cy/Byte", "Mbps");
	for(i=0;i < numPktSizes; i++) {
		double cycles =  (double) cycleCount[i]/ITERATIONS;
		printf("%d", packetSizes[i]);			//Packet size
        printf("\t %8.2f", cycles);		//cycles per op	
		printf("\t %8.2f", average[i]);		//cyles per op average	
       	printf("\t%6.2f", spreads[i]);		//cycles per op	spread
		cycles /= (packetSizes[i] * numBuffs);
		printf("\t    %5.2f", cycles);		//cycles per byte
		Mbps = (cpufreq/cycles);
		Mbps *= 8;
		printf("\t  %7.2f", Mbps);			//Mbps
        printf("\n");
	}
	printf("\n");

	free(pKey);
	freeTestData(IV, pSrcData, pDstData, numPktSizes, numBuffs);
	return 0;
}


