/*************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_SNOW3G.L.0.3.1-409
*
*************************************************************************/

/**
 * @file
 * This header file defines an API for 3GPP algorithms Snow3G f8/f9. 
 */

#ifndef _SSO_SNOW3G_H_
#define _SSO_SNOW3G_H_

#include <stdint.h>

/**
 * Key scheduling structure
 */
typedef struct snow3g_key_schedule_s
{
    /* KEY */
    uint32_t k[4];
} sso_snow3g_key_schedule_t;

/**
 *******************************************************************************
 * This function performs snow3g f8 operation on a single buffer. The key has
 * already been scheduled with sso_snow3g_init_key_sched().
 * 
 * @param[in]       pCtx			Context where the scheduled keys are stored
 * @param[in]       pIV             pIV[3] = count
 *				    				pIV[2] = (bearer << 27) | ((dir & 0x1) << 26)
 *	                            	pIV[1] = pIV[3]
 *	                            	pIV[0] = pIV[2]
 * @param[in]       pBufferIn       Input buffer 
 * @param[out]      pBufferOut      Output buffer
 * @param[in]       cipherLengthInBits   Length in bits of input buffer
 * @param[in]       offsetInBits   offset in input/output buffer (in bits)

 ******************************************************************************/
void sso_snow3g_f8_1_buffer_bit(sso_snow3g_key_schedule_t *pCtx, uint8_t *pIV, uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t cipherLengthInBits, uint32_t offsetInBits);

/**
 *******************************************************************************
 * This function performs snow3g f8 operation on a single buffer. The key has
 * already been scheduled with sso_snow3g_init_key_sched().
 * 
 * @param[in]       pCtx			Context where the scheduled keys are stored
 * @param[in]       pIV             pIV[3] = count
 *				    				pIV[2] = (bearer << 27) | ((dir & 0x1) << 26)
 *	                            	pIV[1] = pIV[3]
 *	                            	pIV[0] = pIV[2]
 * @param[in]       pBufferIn       Input buffer 
 * @param[out]      pBufferOut      Output buffer
 * @param[in]       lengthInBytes   Length in bytes of input buffer
 *
 ******************************************************************************/
void sso_snow3g_f8_1_buffer(sso_snow3g_key_schedule_t *pCtx, uint8_t *pIV, uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t lengthInBytes);

/**
 *******************************************************************************
 * This function performs snow3g f8 operation on two buffers. They will
 * be processed with the same key, which has already been scheduled with
 * sso_snow3g_init_key_sched().
 * 
 * @param[in]       pCtx            	Context where the scheduled keys are stored
 * @param[in]       pIV1            	IV to use for buffer pBufferIn1
 * @param[in]       pIV2            	IV to use for buffer pBufferIn2
 * @param[in]       pBufferIn1      	Input buffer 1
 * @param[out]      pBufferOut1     	Output buffer 1
 * @param[in]       lengthInBytes1  	Length in bytes of input buffer 1 
 * @param[in]       pBufferIn2       	Input buffer 2 
 * @param[out]      pBufferOut2      	Output buffer 2
 * @param[in]       lengthInBytes2  	Length in bytes of input buffer 2 
 *
 ******************************************************************************/
void sso_snow3g_f8_2_buffer(sso_snow3g_key_schedule_t *pCtx, uint8_t *pIV1, uint8_t *pIV2,
                 uint8_t *pBufferIn1, uint8_t *pBufferOut1, uint32_t lengthInBytes1, 
                 uint8_t *pBufferIn2, uint8_t *pBufferOut2, uint32_t lengthInBytes2);

/**
 *******************************************************************************
 * This function performs snow3g f8 operation on four buffers. They will
 * be processed with the same key, which has already been scheduled with
 * sso_snow3g_init_key_sched().
 * 
 * @param[in]       pCtx            	Context where the scheduled keys are stored
 * @param[in]       pIV1            	IV to use for buffer pBufferIn1
 * @param[in]       pIV2            	IV to use for buffer pBufferIn2
 * @param[in]       pIV3            	IV to use for buffer pBufferIn3
 * @param[in]       pIV4            	IV to use for buffer pBufferIn2
 * @param[in]       pBufferIn1      	Input buffer 1
 * @param[out]      pBufferOut1     	Output buffer 1
 * @param[in]       lengthInBytes1  	Length in bytes of input buffer 1 
 * @param[in]       pBufferIn2       	Input buffer 2 
 * @param[out]      pBufferOut2      	Output buffer 2
 * @param[in]       lengthInBytes2  	Length in bytes of input buffer 2 
 * @param[in]       pBufferIn3      	Input buffer 3
 * @param[out]      pBufferOut3     	Output buffer 3
 * @param[in]       lengthInBytes3  	Length in bytes of input buffer 3 
 * @param[in]       pBufferIn4      	Input buffer 4
 * @param[out]      pBufferOut4     	Output buffer 4
 * @param[in]       lengthInBytes4  	Length in bytes of input buffer 4 
 *
 ******************************************************************************/
void sso_snow3g_f8_4_buffer(sso_snow3g_key_schedule_t *pCtx, uint8_t *pIV1, uint8_t *pIV2, uint8_t *pIV3, uint8_t *pIV4, 
                uint8_t *pBufferIn1, uint8_t *pBufferOut1, uint32_t lengthInBytes1, 
                uint8_t *pBufferIn2, uint8_t *pBufferOut2, uint32_t lengthInBytes2, 
                uint8_t *pBufferIn3, uint8_t *pBufferOut3, uint32_t lengthInBytes3, 
                uint8_t *pBufferIn4, uint8_t *pBufferOut4, uint32_t lengthInBytes4);
/**
 *******************************************************************************
 * This function performs snow3g f8 operation in parallel on N buffers. All input 
 * buffers can have different lengths and they will be processed with the same
 * key, which has already been scheduled with sso_snow3g_init_key_sched().
 * 
 * @param[in]       pCtx            		Context where the scheduled keys are stored
 * @param[in]       IV[]           	    	Array of IV values
 * @param[in]       pBufferIn[]     		Array of input buffers 
 * @param[out]      pBufferOut[]    		Array of output buffers
 * @param[in]       bufferLenInBytes[]  	Array of corresponding input buffer lengths 
 * @param[in]       bufferCount     		Number of input buffers
 *
 ******************************************************************************/
void sso_snow3g_f8_n_buffer(sso_snow3g_key_schedule_t *pCtx, uint8_t* IV[],
                            uint8_t *pBufferIn[], uint8_t *pBufferOut[],
			    			uint32_t bufferLenInBytes[], uint32_t bufferCount);

/**
 *******************************************************************************
 * This function performs a snow3g f9 operation on a single block of data. The
 * key has already been scheduled with sso_snow3g_init_f8_key_sched().
 *
 * @param[in]       pCtx            Context where the scheduled keys are stored
 * @param[in]       pIV             pIV[3] = __builtin_bswap32(fresh^(dir<<15))
 *	    			    pIV[2] = __builtin_bswap32(count^(dir<<31))
 *	                            pIV[1] = __builtin_bswap32(fresh)
 *  	                            pIV[0] = __builtin_bswap32(count)
 *
 * @param[in]       pBufferIn       Input buffer 
 * @param[in]       lengthInBits    Length in bits of the data to be hashed
 * @param[out]      pDigest         Computed digest
 *
 ******************************************************************************/
void sso_snow3g_f9_1_buffer( sso_snow3g_key_schedule_t *pCtx,  uint8_t *pIV, uint8_t *pBufferIn, uint64_t lengthInBits, uint8_t *pDigest );


/**
 *******************************************************************************
 * This function returns the size of the sso_snow3g_key_schedule_t, used
 * to store the key schedule.
 *
 * @return	size of sso_snow3g_key_schedule_t type success
 * @return	-1 on failed CPU capability check
 *   
 ******************************************************************************/
uint32_t sso_snow3g_key_sched_size(void);


/**
 *******************************************************************************
 * Snow3g key schedule init function.
 * 
 * @param[in]    	pKey        Confidentiality/Integrity key (expected in LE format)
 * @param[out]		pCtx    	Key schedule context to be initialised
 * @return	0 on success
 *
 ******************************************************************************/
uint32_t sso_snow3g_init_key_sched(uint8_t *pKey, sso_snow3g_key_schedule_t *pCtx);

/**
 *******************************************************************************
 * This function is used to check the CPU capabilities defined 
 * in the top level Makefile.  
 *
 * @return	0 if specifed processor capabilities are available
 *
 ******************************************************************************/
uint32_t sso_snow3g_cpuid_check(void);

#endif  /* _SSO_SNOW3G_H_ */

