/***************************************************************************
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_SNOW3G.L.0.3.1-409
*
***************************************************************************/

/*-----------------------------------------------------------------------
*
* An implementation of SNOW 3G, the core algorithm for the
* 3GPP Confidentiality and Integrity algorithms.
*
*-----------------------------------------------------------------------*/

#ifdef IACA
#include <iacaMarks.h>
#endif

#include "sso_snow3g.h"
#include "sso_snow3g_internal.h"
#include "sso_common.h"
#define arch_bswap64 __builtin_bswap64

/* -------------------------------------------------------------------
* LFSR array shift by 1 position, 4 packets at a time
* ------------------------------------------------------------------ */
#if (!defined(SNOW3G_C))
/* LFSR array shift */
static inline void ShiftLFSR_4(sso_snow3gKeyState4_t *pCtx)
{
   pCtx->iLFSR_X = (pCtx->iLFSR_X + 1) % 16;
}

#endif

#if (!defined(SNOW3G_C))
/* -------------------------------------------------------------------
* ClockLFSR sub-function as defined in snow3g standard
* S = LFSR[2]
*     ^ table_Alpha_div[LFSR[11] & 0xff]
*     ^ table_Alpha_mul[LFSR[0] & 0xff]
* ------------------------------------------------------------------ */
static inline void C0_C11_4(uint32_t *S, const __m128i *L0, const __m128i *L11)
{
#ifdef IACA
  IACA_START
#endif
    unsigned B11[4], B0[4];
    B11[0] = _mm_extract_epi8(*L11, 0);
    B11[1] = _mm_extract_epi8(*L11, 4);
    B11[2] = _mm_extract_epi8(*L11, 8);
    B11[3] = _mm_extract_epi8(*L11, 12);

    S[0] = sso_snow3g_table_A_div[B11[0]];
    S[1] = sso_snow3g_table_A_div[B11[1]];
    S[2] = sso_snow3g_table_A_div[B11[2]];
    S[3] = sso_snow3g_table_A_div[B11[3]];

    B0[0] = _mm_extract_epi8(*L0, 3);
    B0[1] = _mm_extract_epi8(*L0, 7);
    B0[2] = _mm_extract_epi8(*L0, 11);
    B0[3] = _mm_extract_epi8(*L0, 15);

    S[0] ^= sso_snow3g_table_A_mul[B0[0]];
    S[1] ^= sso_snow3g_table_A_mul[B0[1]];
    S[2] ^= sso_snow3g_table_A_mul[B0[2]];
    S[3] ^= sso_snow3g_table_A_mul[B0[3]];
#ifdef IACA
  IACA_END
#endif   
}
/* -------------------------------------------------------------------
* ClockLFSR function as defined in snow3g standard
* S =   table_Alpha_div[LFSR[11] & 0xff]
*     ^ table_Alpha_mul[LFSR[0] >> 24]
*     ^ LFSR[2] ^ LFSR[0] << 8 ^ LFSR[11] >> 8
* ------------------------------------------------------------------ */
static inline void ClockLFSR_4(sso_snow3gKeyState4_t *pCtx)
{
    uint32_t X2[4];
    __m128i S, T, U;
    U = pCtx->LFSR_X[pCtx->iLFSR_X];
    S = pCtx->LFSR_X[(pCtx->iLFSR_X + 11)%16];
	C0_C11_4(X2, &U, &S);

    T = _mm_slli_epi32(U, 8);
    S = _mm_srli_epi32(S, 8);
    U = _mm_xor_si128(T, pCtx->LFSR_X[(pCtx->iLFSR_X + 2)%16]);
    ShiftLFSR_4(pCtx);

	/* (SSE4) */
    T = _mm_insert_epi32(T, X2[0], 0);
    T = _mm_insert_epi32(T, X2[1], 1);
    T = _mm_insert_epi32(T, X2[2], 2);
    T = _mm_insert_epi32(T, X2[3], 3);
    S = _mm_xor_si128(S, U);
    S = _mm_xor_si128(S, T);
    pCtx->LFSR_X[(pCtx->iLFSR_X + 15)%16] = S; 
}

#endif

#if (!defined(SNOW3G_C))

/* -------------------------------------------------------------------
* ClockFSM function as defined in snow3g standard
* 4 packets at a time
* ------------------------------------------------------------------ */
static inline void ClockFSM_4(sso_snow3gKeyState4_t *pCtx, __m128i *data)
{
    __m128i F, R;
#ifdef __INTEL_COMPILER
#pragma warning(push)
#pragma warning disable 592
    uint32_t L = L;
    uint32_t K = K;
#pragma warning(pop)
#else
    uint32_t L = L;
    uint32_t K = K;
#endif
#ifdef IACA
//    IACA_START
#endif
    F = _mm_add_epi32(pCtx->LFSR_X[(pCtx->iLFSR_X + 15)%16], pCtx->FSM_X[0]);
    R = _mm_xor_si128(pCtx->LFSR_X[(pCtx->iLFSR_X + 5)%16], pCtx->FSM_X[2]);
    *data = _mm_xor_si128(F, pCtx->FSM_X[1]);
    R = _mm_add_epi32(R, pCtx->FSM_X[1]);
    S1_S2_4(pCtx->FSM_X[2], pCtx->FSM_X[1], pCtx->FSM_X[0], K, L, 0);
    S1_S2_4(pCtx->FSM_X[2], pCtx->FSM_X[1], pCtx->FSM_X[0], K, L, 1);
    S1_S2_4(pCtx->FSM_X[2], pCtx->FSM_X[1], pCtx->FSM_X[0], K, L, 2);
    S1_S2_4(pCtx->FSM_X[2], pCtx->FSM_X[1], pCtx->FSM_X[0], K, L, 3);
    pCtx->FSM_X[0] = R;
#ifdef IACA
  //  IACA_END
#endif
}

#endif

/**
 *******************************************************************************
 * @description 
 * This function generates 4 bytes of keystream 1 buffer at a time
 * 
 * @param[in]       pCtx     		Context where the scheduled keys are stored
 * @param[in/out]   pKeyStream     	Pointer to generated keystream
 *
 *******************************************************************************/

static inline void sso_snow3g_keystream_1_4(sso_snow3gKeyState1_t *pCtx, uint32_t *pKeyStream)
{
    uint32_t F;

    ClockFSM_1(pCtx, &F);
    *pKeyStream = F ^ pCtx->LFSR_S[0];
    ClockLFSR_1(pCtx);
}

/**
 *******************************************************************************
 * @description 
 * This function generates 8 bytes of keystream 1 buffer at a time
 * 
 * @param[in]       pCtx     		Context where the scheduled keys are stored
 * @param[in/out]   pKeyStream     	Pointer to generated keystream
 *
 *******************************************************************************/

static inline void sso_snow3g_keystream_1_8(sso_snow3gKeyState1_t *pCtx, uint64_t *pKeyStream)
{
    uint64_t F;
    uint32_t FSM4;
    uint32_t V0, V1;
    uint32_t F0, F1;
    uint32_t R0, R1;
    uint32_t L0, L1, L11, L12;

    /* Merged clock FSM + clock LFSR + clock FSM + clockLFSR 
    * in order to avoid redundancies in function processing
    * and less instruction immediate dependencies
    */
    L0 = pCtx->LFSR_S[0];
    V0 = pCtx->LFSR_S[2];
    L1 = pCtx->LFSR_S[1];
    V1 = pCtx->LFSR_S[3];
    R1 = pCtx->FSM_R1;
    L11 = pCtx->LFSR_S[11];
    L12 = pCtx->LFSR_S[12];
    V0 ^= sso_snow3g_table_A_mul[L0 >> 24];
    V1 ^= sso_snow3g_table_A_mul[L1 >> 24];
    V0 ^= sso_snow3g_table_A_div[L11 & 0xff];
    V1 ^= sso_snow3g_table_A_div[L12 & 0xff];
    V0 ^= L0 << 8;
    V1 ^= L1 << 8;
    V0 ^= L11 >> 8;
    V1 ^= L12 >> 8;
    F0 = pCtx->LFSR_S[15] + R1;
    F0 ^= L0;
    F0 ^= pCtx->FSM_R2;
    R0 = pCtx->FSM_R3 ^ pCtx->LFSR_S[5];
    R0 += pCtx->FSM_R2;
    S1_S2_S3_1(pCtx->FSM_R3, pCtx->FSM_R2, R1, FSM4, R0);
    R1 = pCtx->FSM_R3 ^ pCtx->LFSR_S[6];
    F1 = V0 + R0;
    F1 ^= L1;
    F1 ^= pCtx->FSM_R2;
    R1 += pCtx->FSM_R2;
    pCtx->FSM_R3 = S2(pCtx->FSM_R2);
    pCtx->FSM_R2 = FSM4;
    pCtx->FSM_R1 = R1;

    /* Shift LFSR twice */
    ShiftTwiceLFSR_1(pCtx);

    /* keystream mode LFSR update */
    pCtx->LFSR_S[14] = V0;
    pCtx->LFSR_S[15] = V1;

    F = F0;
    F <<= 32;
    F |= (uint64_t)F1;

    *pKeyStream = F;
}

#if (!defined(SNOW3G_C))
/**
 *******************************************************************************
 * @description 
 * This function generates 4 bytes of keystream 4 buffers at a time
 * 
 * @param[in]       pCtx     		Context where the scheduled keys are stored
 * @param[in/out]   pKeyStream     	Pointer to generated keystream
 *
 *******************************************************************************/

static inline void sso_snow3g_keystream_4_4(sso_snow3gKeyState4_t *pCtx, __m128i *pKeyStream)
{
    __m128i F;
    ClockFSM_4(pCtx, &F);
    *pKeyStream = _mm_xor_si128(F, pCtx->LFSR_X[pCtx->iLFSR_X]);
     ClockLFSR_4(pCtx);
}

/**
 *******************************************************************************
 * @description 
 * This function generates 8 bytes of keystream 4 buffers at a time
 * 
 * @param[in]       pCtx     	    Context where the scheduled keys are stored
 * @param[in/out]   pKeyStreamLo    Pointer to lower end of generated keystream
 * @param[in/out]   pKeyStreamHi    Pointer to higer end of generated keystream
 *
 *******************************************************************************/

static inline void sso_snow3g_keystream_4_8(sso_snow3gKeyState4_t *pCtx, __m128i *pKeyStreamLo, __m128i *pKeyStreamHi)
{
    __m128i H, L;

    /* first set of 4 bytes */
    ClockFSM_4(pCtx, &L);
    L = _mm_xor_si128(L, pCtx->LFSR_X[pCtx->iLFSR_X]);
    ClockLFSR_4(pCtx);

    /* second set of 4 bytes */
    ClockFSM_4(pCtx, &H);
    H = _mm_xor_si128(H, pCtx->LFSR_X[pCtx->iLFSR_X]);
    ClockLFSR_4(pCtx);

    /* merge the 2 sets */
    *pKeyStreamLo = _mm_unpacklo_epi32(H, L);
    *pKeyStreamHi = _mm_unpackhi_epi32(H, L);

}

#endif

#if (!defined (SNOW3G_C))

/**
 *******************************************************************************
 * @description 
 * This function initializes the key schedule for 4 buffers for snow3g f8/f9.
 *
 *  @param[in]      pCtx     		Context where the scheduled keys are stored
 *  @param [in]     pKeySched		Key schedule
 *  @param [in]     pIV1  	 	IV for buffer 1 
 *  @param [in]     pIV2  	 	IV for buffer 2 
 *  @param [in]     pIV3  	 	IV for buffer 3 
 *  @param [in]     pIV4  	 	IV for buffer 4 
 *
 *******************************************************************************/
static inline void sso_snow3gStateInitialize_4(sso_snow3gKeyState4_t *pCtx, 
                                           sso_snow3g_key_schedule_t *pKeySched, 
                                           uint8_t *pIV1, uint8_t *pIV2, 
                                           uint8_t *pIV3, uint8_t *pIV4)
{
    uint32_t K, L;
    int i;
    __m128i R, S, T, U;
    __m128i V0, V1, T0, T1; 

    /* Initialize the LFSR table from constants, Keys, and IV */

     /* Load complete 128b IV into register (SSE2)*/ 
    __m128i swapMask = { 0x0405060700010203ULL , 0x0c0d0e0f08090a0bULL };
    R =  _mm_loadu_si128((const __m128i *)pIV1);
    S =  _mm_loadu_si128((const __m128i *)pIV2);
    T =  _mm_loadu_si128((const __m128i *)pIV3);
    U =  _mm_loadu_si128((const __m128i *)pIV4);

    /* initialize the array block (SSE4) */
    for (i = 0; i < 4; i++)
    {
        K = pKeySched->k[i];
        L = ~K;
        V0 = _mm_set1_epi32(K);
        V1 = _mm_set1_epi32(L);
        pCtx->LFSR_X[i + 4] = V0;
        pCtx->LFSR_X[i + 12] = V0;
        pCtx->LFSR_X[i + 0] = V1;
        pCtx->LFSR_X[i + 8] = V1;
    }
    /* Update the schedule structure with IVs */
    /* Store the 4 IVs in LFSR by a column/row matrix swap
     * after endianness correction */

  
    /* endianness swap (SSSE3) */
    R =  _mm_shuffle_epi8(R, swapMask);
    S =  _mm_shuffle_epi8(S, swapMask);
    T =  _mm_shuffle_epi8(T, swapMask);
    U =  _mm_shuffle_epi8(U, swapMask);

    /* row/column dword inversion (SSE2) */
    T0 = _mm_unpacklo_epi32(R, S); 
    R =  _mm_unpackhi_epi32(R, S); 
    T1 = _mm_unpacklo_epi32(T, U); 
    T =  _mm_unpackhi_epi32(T, U); 

    /* row/column qword inversion (SSE2) */
    U =  _mm_unpackhi_epi64(R, T); 
    T =  _mm_unpacklo_epi64(R, T); 
    S =  _mm_unpackhi_epi64(T0, T1); 
    R =  _mm_unpacklo_epi64(T0, T1); 

    /*IV ^ LFSR  (SSE2) */
    pCtx->LFSR_X[15] = _mm_xor_si128(pCtx->LFSR_X[15], U);
    pCtx->LFSR_X[12] = _mm_xor_si128(pCtx->LFSR_X[12], T);
    pCtx->LFSR_X[10] = _mm_xor_si128(pCtx->LFSR_X[10], S);
    pCtx->LFSR_X[9]  = _mm_xor_si128(pCtx->LFSR_X[9], R);
    pCtx->iLFSR_X = 0;
    /* FSM initialization (SSE2) */
    S = _mm_setzero_si128();
    for (i = 0; i < 3; i++)
    {
        pCtx->FSM_X[i] = S;
    }

    /* Initialisation rounds */
    for(i = 0; i < 32; i++)
    {
        ClockFSM_4(pCtx, &S);
        ClockLFSR_4(pCtx);
        pCtx->LFSR_X[(pCtx->iLFSR_X + 15)%16] = _mm_xor_si128(pCtx->LFSR_X[(pCtx->iLFSR_X + 15)%16], S);
    }

}

#endif
#define ComplementaryMask64(x) ((~(x)%64)+1)
#define ComplementaryMask32(x) ((~(x)%32)+1)

/**
 *******************************************************************************
 * @description 
 * This function is the core snow3g bit algorithm for the 3GPP confidentiality algorithm
 * 
 * @param[in]       pCtx          		Context where the scheduled keys are stored
 * @param[in]       pBufferIn         	Input buffer 
 * @param[out]      pBufferOut        	Output buffer
 * @param[in]       cipherLengthInBits  length in bits of the data to be encrypted
 * @param[in]       bitOffset     	    offset in input buffer, where data are valid
 *
 *******************************************************************************/
static inline void sso_f8_snow3g_bit(sso_snow3gKeyState1_t *pCtx, uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t cipherLengthInBits, uint32_t offsetInBits)
{
    uint32_t qwords = (cipherLengthInBits + 7 + offsetInBits%8) / (SNOW3G_8_BYTES*8);  /* number of qwords */
    uint32_t words;
    uint32_t bytes;
    uint32_t KS4, KS4bit;  /* 4 bytes of keystream */
    uint32_t keyMask4, bufMask4;
    uint64_t keyMask8, bufMask8;
    uint64_t KS8, KS8bit;  /* 8 bytes of keystream */
    uint64_t initStream;
    uint64_t* pInitStream;
    uint8_t* pcBufferIn = pBufferIn + (offsetInBits/64)*8;
    uint8_t* pcBufferOut = pBufferOut + (offsetInBits/64)*8;
    uint32_t offsetInBitsResidue32 = offsetInBits%32;
    uint32_t offsetInBitsResidue64 = offsetInBits%64;

    pInitStream = (uint64_t*)pcBufferIn; 
    typedef union uShiftRem {
        uint64_t b64;
        uint32_t b32[2];
    }uShiftRem;
    uShiftRem shiftrem;
#if (!defined (_3GPP_SAFE_BUFFERS))
    uint32_t partialRange;
    uint32_t byteLength = (cipherLengthInBits + 7)/8;
    typedef union SafeBuffer {
        uint64_t b64;
        uint32_t b32[2];
        uint8_t  b8[SNOW3G_8_BYTES];
    }SafeBuf;

    SafeBuf  safeInBuf;
    SafeBuf  safeOutBuf; 
    partialRange = SNOW3G_8_BYTES - ((offsetInBits/8)- ((offsetInBits/64)*8));
    if (byteLength <=  partialRange)
    { 
        memset(safeInBuf.b8, 0, SNOW3G_8_BYTES);
        memset(safeOutBuf.b8, 0, SNOW3G_8_BYTES);	
        sso_memcpy_keystrm(safeInBuf.b8, pcBufferIn, partialRange);
        sso_memcpy_keystrm(safeOutBuf.b8, pcBufferOut, partialRange);
        if (offsetInBitsResidue64) {
            shiftrem.b64 =  arch_bswap64(safeOutBuf.b64) & ((uint64_t)-1  << ComplementaryMask64(offsetInBits));
            safeInBuf.b64 =  (safeInBuf.b64) & arch_bswap64((uint64_t)-1 >> (offsetInBitsResidue64));
        } else {
            shiftrem.b64 = 0;
        }
        sso_snow3g_keystream_1_8(pCtx, &KS8);
        KS8bit = KS8 >> (offsetInBitsResidue64) | shiftrem.b64;
        /* xor keystream 8 bytes at a time */
        (void) sso_xor_keystrm_rev(safeOutBuf.b8, safeInBuf.b8, KS8bit);
        sso_memcpy_keystrm(pcBufferOut, safeOutBuf.b8, partialRange);
        return;
    } else {
        initStream =  *(uint64_t*)pcBufferIn; 
    } 
#else
    initStream =  *(uint64_t*)pcBufferIn; 

#endif
    if (offsetInBitsResidue64) {
       shiftrem.b64 =  arch_bswap64(*(uint64_t*)pcBufferOut) & ((uint64_t)-1  << ComplementaryMask64(offsetInBits));
        *(uint64_t*)pcBufferIn =  (*(uint64_t*)pcBufferIn) & arch_bswap64((uint64_t)-1 >> offsetInBitsResidue64);
    } else {
        shiftrem.b64 = 0;
    }
    if ((offsetInBitsResidue64) && (qwords)) {
       cipherLengthInBits += SNOW3G_8_BYTES*8 - ComplementaryMask64(offsetInBits);//offsetInBitsResidue64; /* done another 64 bits */
    } 
 
    /* process 64 bits at a time */
    while (qwords--)
    {
        /* generate keystream 8 bytes at a time */
        sso_snow3g_keystream_1_8(pCtx, &KS8);
        KS8bit = KS8 >> (offsetInBitsResidue64)|shiftrem.b64 ;
        shiftrem.b64 = (KS8  << (63 - offsetInBitsResidue64))<< 1 ; 
        /* xor keystream 8 bytes at a time */
        pcBufferIn = sso_xor_keystrm_rev(pcBufferOut, pcBufferIn, KS8bit);
        pcBufferOut += SNOW3G_8_BYTES;
        cipherLengthInBits -= SNOW3G_8_BYTES*8;
    }
    /* check for remaining 0 to 7 bytes  */
    words = cipherLengthInBits & (4*8);
    bytes =  cipherLengthInBits & (4*8 - 1);
    if (0 != words)
    {
        if (bytes)
        {
            bufMask8 = (((uint64_t)-1<<8)  << (cipherLengthInBits/8*8)) | ((((uint64_t)256 >> (cipherLengthInBits%8)) - 1) << (cipherLengthInBits/8*8));
            keyMask8 = (uint64_t)-1  << ComplementaryMask64(cipherLengthInBits);
            /* 5 to 7 last bytes, process 8 bytes */
#if (defined (_3GPP_SAFE_BUFFERS))
            sso_snow3g_keystream_1_8(pCtx, &KS8);
            KS8bit = KS8 >> (offsetInBitsResidue64)|shiftrem.b64;
            KS8bit = (KS8bit & keyMask8) | arch_bswap64(*(uint64_t*)pcBufferOut & bufMask8);
            KS8  =  (*(uint64_t*)pcBufferIn) & ~bufMask8;//_bswap64(~mask8);
            sso_xor_keystrm_rev(pcBufferOut, (uint8_t*)& KS8, KS8bit);
#else
            SafeBuf safeBuff;
	        memset(safeBuff.b8, 0, SNOW3G_8_BYTES);	
            sso_memcpy_keystrm(safeBuff.b8, pcBufferOut,SNOW3G_8_BYTES);
            sso_snow3g_keystream_1_8(pCtx, &KS8);
            KS8bit = KS8 >> (offsetInBitsResidue64)|shiftrem.b64;
            KS8bit = (KS8bit & keyMask8) | arch_bswap64(safeBuff.b64 & bufMask8);
            KS8  =  *(uint64_t*)pcBufferIn & ~bufMask8;
            sso_xor_keystrm_rev(safeBuff.b8, (uint8_t*)&KS8, KS8bit);
            sso_memcpy_keystrm(pcBufferOut, safeBuff.b8, (cipherLengthInBits + 7)/8/*SNOW3G_8_BYTES*/);
#endif
        } else {
            /* exactly 4 last bytes */
            bufMask4 = ((uint32_t)0xFFFFFF00 << (cipherLengthInBits/8*8))|((((uint32_t)256 >> (cipherLengthInBits%8))-1) << (cipherLengthInBits/8*8));
            keyMask4 = (uint32_t)-1  << ComplementaryMask32(cipherLengthInBits);
            sso_snow3g_keystream_1_4(pCtx, &KS4);
            KS4bit = KS4 >> (offsetInBitsResidue32)|shiftrem.b32[1];
            shiftrem.b32[1] = (KS4  << (31 - (offsetInBitsResidue32)))<< 1 ; 
            sso_xor_keystream_reverse_32(pcBufferOut, pcBufferIn, KS4bit);
            pcBufferOut += SNOW3G_4_BYTES;
            cipherLengthInBits -= SNOW3G_4_BYTES*8;
            if (cipherLengthInBits) {            
                KS4bit = KS4 >> (offsetInBitsResidue32)|shiftrem.b32[1];
                bufMask4 = ((uint32_t)-1  << ((cipherLengthInBits/8)*8)) | (((uint32_t)1 << (8 - cipherLengthInBits%8)) - 1);
                keyMask4 = (uint32_t)-1  << ComplementaryMask32(cipherLengthInBits);
                KS4bit = (KS4bit & keyMask4) | __builtin_bswap32(*(uint32_t*)pcBufferOut & bufMask4);
                KS4  =  (*(uint32_t*)pcBufferIn) & ~bufMask4;
                sso_xor_keystream_reverse_32(pcBufferOut, (uint8_t*)&KS4, KS4bit);
            }
 
        }
    } else if (0 != bytes)
    { 
         bufMask4 = ((uint32_t)0xFFFFFF00 << (cipherLengthInBits/8*8))|((((uint32_t)256 >> (cipherLengthInBits%8))-1) << (cipherLengthInBits/8*8));
         keyMask4 = (uint32_t)-1  << ComplementaryMask32(cipherLengthInBits);
        /* 1 to 3 last bytes */
#if (defined (_3GPP_SAFE_BUFFERS))
        /* exactly 4 last bytes */
        sso_snow3g_keystream_1_4(pCtx, &KS4);
        KS4bit = KS4 >> (offsetInBitsResidue32)|shiftrem.b32[1];
        KS4bit = (KS4bit & keyMask4) | __builtin_bswap32(*(uint32_t*)pcBufferOut & bufMask4);
        KS4  =  (*(uint32_t*)pcBufferIn) & ~bufMask4;

        sso_xor_keystream_reverse_32(pcBufferOut, (uint8_t*)&KS4, KS4bit);

#else
        sso_memcpy_keystrm(safeInBuf.b8, pcBufferIn, SNOW3G_4_BYTES);
        sso_memcpy_keystrm(safeOutBuf.b8, pcBufferOut, SNOW3G_4_BYTES);
        sso_snow3g_keystream_1_4(pCtx, &KS4);
        KS4bit = KS4 >> (offsetInBitsResidue32)|shiftrem.b32[1];
        KS4bit = (KS4bit & keyMask4) | __builtin_bswap32(safeOutBuf.b32[0] & bufMask4);
        KS4  =  safeInBuf.b32[0] & ~bufMask4;
        sso_xor_keystream_reverse_32(safeOutBuf.b8, (uint8_t*)&KS4, KS4bit);
        sso_memcpy_keystrm(pcBufferOut, &safeOutBuf.b8[0], (cipherLengthInBits + 7)/8/*SNOW3G_4_BYTES*/);


#endif
    }
    *pInitStream = initStream;
}
/**
 *******************************************************************************
 * @description 
 * This function is the core snow3g algorithm for the 3GPP confidentiality and integrity algorithm.
 * 
 * @param[in]       pCtx          		Context where the scheduled keys are stored
 * @param[in]       pBufferIn         	Input buffer 
 * @param[out]      pBufferOut        	Output buffer
 * @param[in]       lengthInBytes     	length in bytes of the data to be encrypted
 *
 *******************************************************************************/

static inline void sso_f8_snow3g(sso_snow3gKeyState1_t *pCtx, uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t lengthInBytes)
{
    uint32_t qwords = lengthInBytes / SNOW3G_8_BYTES;  /* number of qwords */
    uint32_t words = lengthInBytes & 4;   /* remaining word if not 0 */
    uint32_t bytes = lengthInBytes & 3;   /* remaining bytes */
    uint32_t KS4;  /* 4 bytes of keystream */
    uint64_t KS8;  /* 8 bytes of keystream */


    /* process 64 bits at a time */
    while (qwords--)
    {

	
        /* generate keystream 8 bytes at a time */
        sso_snow3g_keystream_1_8(pCtx, &KS8);

        /* xor keystream 8 bytes at a time */
        pBufferIn = sso_xor_keystrm_rev(pBufferOut, pBufferIn, KS8);
        pBufferOut += SNOW3G_8_BYTES;

    }

    /* check for remaining 0 to 7 bytes  */
    if (0 != words)
    {
        if (bytes)
        {

            /* 5 to 7 last bytes, process 8 bytes */
#if (defined (_3GPP_SAFE_BUFFERS))
            sso_snow3g_keystream_1_8(pCtx, &KS8);
            sso_xor_keystrm_rev(pBufferOut, pBufferIn, KS8);
#else
            uint8_t buftemp[8];
            uint8_t safeBuff[8];
	    memset(safeBuff, 0, SNOW3G_8_BYTES);	
            sso_snow3g_keystream_1_8(pCtx, &KS8);
            sso_memcpy_keystrm(safeBuff, pBufferIn, 4 + bytes);
            sso_xor_keystrm_rev(buftemp, safeBuff, KS8);
            sso_memcpy_keystrm(pBufferOut, buftemp, 4 + bytes);
#endif
        }
        else
        {

            /* exactly 4 last bytes */
            sso_snow3g_keystream_1_4(pCtx, &KS4);
            sso_xor_keystream_reverse_32(pBufferOut, pBufferIn, KS4);
	
        }
    }
    else if (0 != bytes)
    { 

        /* 1 to 3 last bytes */
#if (defined (_3GPP_SAFE_BUFFERS))
        sso_snow3g_keystream_1_4(pCtx, &KS4);
        sso_xor_keystream_reverse_32(pBufferOut, pBufferIn, KS4);
#else
        uint8_t buftemp[4];
        uint8_t safeBuff[4];
	memset(safeBuff, 0, SNOW3G_4_BYTES);
        sso_snow3g_keystream_1_4(pCtx, &KS4);
        sso_memcpy_keystream_32(safeBuff, pBufferIn, bytes);
        sso_xor_keystream_reverse_32(buftemp, safeBuff, KS4);
        sso_memcpy_keystream_32(pBufferOut, buftemp, bytes);
	
#endif
    }
}

/*---------------------------------------------------------
* f8()
* Initializations and Context size definitions
*---------------------------------------------------------*/
uint32_t sso_snow3g_key_sched_size(void)
{

    return sizeof(sso_snow3g_key_schedule_t);
}

uint32_t sso_snow3g_init_key_sched(uint8_t *pKey, sso_snow3g_key_schedule_t *pCtx)
{
    sso_snow3g_key_schedule_t *pLocalCtx = (sso_snow3g_key_schedule_t *)pCtx;
    pLocalCtx->k[3] =  __builtin_bswap32(*((uint32_t*)&pKey[0]));
    pLocalCtx->k[2] =  __builtin_bswap32(*((uint32_t*)&pKey[4]));
    pLocalCtx->k[1] =  __builtin_bswap32(*((uint32_t*)&pKey[8]));
    pLocalCtx->k[0] =  __builtin_bswap32(*((uint32_t*)&pKey[12]));
    return 0;
}


/*---------------------------------------------------------
* @description
* 	Snow3G F8 1 buffer:
* 	Single buffer enc/dec with IV and precomputed key schedule
*---------------------------------------------------------*/

void sso_snow3g_f8_1_buffer(sso_snow3g_key_schedule_t *pHandle, uint8_t *pIV, 
                 uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t lengthInBytes )
{
    sso_snow3g_key_schedule_t *pKey = (sso_snow3g_key_schedule_t *)pHandle;
    sso_snow3gKeyState1_t ctx;
    uint32_t KS4;  /* 4 bytes of keystream */

    /* Initialize the schedule from the IV */ 
    sso_snow3gStateInitialize_1(&ctx, pKey, pIV);

    /* Clock FSM and LFSR once, ignore the keystream */ 
    sso_snow3g_keystream_1_4(&ctx, &KS4);

    sso_f8_snow3g(&ctx, pBufferIn, pBufferOut, lengthInBytes);
}
/*---------------------------------------------------------
* @description
* 	Snow3G F8 bit 1 buffer:
* 	Single buffer enc/dec with IV and precomputed key schedule
*---------------------------------------------------------*/

void sso_snow3g_f8_1_buffer_bit(sso_snow3g_key_schedule_t *pHandle, uint8_t *pIV, 
                 uint8_t *pBufferIn, uint8_t *pBufferOut, uint32_t lengthInBits, uint32_t offsetInBits )
{
    sso_snow3g_key_schedule_t *pKey = (sso_snow3g_key_schedule_t *)pHandle;
    sso_snow3gKeyState1_t ctx;
    uint32_t KS4;  /* 4 bytes of keystream */

    /* Initialize the schedule from the IV */ 
    sso_snow3gStateInitialize_1(&ctx, pKey, pIV);

    /* Clock FSM and LFSR once, ignore the keystream */ 
    sso_snow3g_keystream_1_4(&ctx, &KS4);

    sso_f8_snow3g_bit(&ctx, pBufferIn, pBufferOut, lengthInBits, offsetInBits);
}
/*---------------------------------------------------------
* @description
* 	Snow3G F8 2 buffer:
* 	Two buffers enc/dec with the same key schedule.
* 	The 3 IVs are independent and are passed as an array of pointers.
* 	Each buffer and data length are separate.
*---------------------------------------------------------*/

void sso_snow3g_f8_2_buffer(sso_snow3g_key_schedule_t *pHandle, uint8_t *pIV1, uint8_t *pIV2, 
                 uint8_t *pBufferIn1, uint8_t *pBufferOut1, uint32_t lengthInBytes1,
                 uint8_t *pBufferIn2, uint8_t *pBufferOut2, uint32_t lengthInBytes2 )
{
    sso_snow3g_key_schedule_t *pKey = (sso_snow3g_key_schedule_t *)pHandle;
    sso_snow3gKeyState1_t ctx1, ctx2;
    uint32_t KS4;  /* 4 bytes of keystream */

    /* Initialize the schedule from the IV */ 
    sso_snow3gStateInitialize_1(&ctx1, pKey, pIV1);

    /* Clock FSM and LFSR once, ignore the keystream */ 
    sso_snow3g_keystream_1_4(&ctx1, &KS4);

    /* data processing for packet 1 */
    sso_f8_snow3g(&ctx1, pBufferIn1, pBufferOut1, lengthInBytes1);

    /* Initialize the schedule from the IV */ 
    sso_snow3gStateInitialize_1(&ctx2, pKey, pIV2);

    /* Clock FSM and LFSR once, ignore the keystream */ 
    sso_snow3g_keystream_1_4(&ctx2, &KS4);

    /* data processing for packet 2 */
    sso_f8_snow3g(&ctx2, pBufferIn2, pBufferOut2, lengthInBytes2);
}

/*---------------------------------------------------------
* @description
* 	Snow3G F8 4 buffer:
* 	Four packets enc/dec with the same key schedule.
* 	The 4 IVs are independent and are passed as an array of pointers.
* 	Each buffer and data length are separate.
*---------------------------------------------------------*/

void sso_snow3g_f8_4_buffer(sso_snow3g_key_schedule_t *pHandle, uint8_t *pIV1, uint8_t *pIV2, uint8_t *pIV3, uint8_t *pIV4, 
                        uint8_t *pBufferIn1, uint8_t *pBufferOut1, uint32_t lengthInBytes1, 
                        uint8_t *pBufferIn2, uint8_t *pBufferOut2, uint32_t lengthInBytes2, 
                        uint8_t *pBufferIn3, uint8_t *pBufferOut3, uint32_t lengthInBytes3, 
                        uint8_t *pBufferIn4, uint8_t *pBufferOut4, uint32_t lengthInBytes4 )
{
#if (defined(SNOW3G_C))  
    sso_snow3g_f8_2_buffer(pHandle, pIV1, pIV2, pBufferIn1, pBufferOut1, lengthInBytes1, 
        pBufferIn2, pBufferOut2, lengthInBytes2);

    sso_snow3g_f8_2_buffer(pHandle, pIV3, pIV4, pBufferIn3, pBufferOut3, lengthInBytes3, 
        pBufferIn4, pBufferOut4, lengthInBytes4);

#else
#if ( !defined (_3GPP_SAFE_BUFFERS)) 
    typedef union SafeBuffer {
        uint64_t b64;
        uint32_t b32[2];
        uint8_t  b8[SNOW3G_8_BYTES];
    }SafeBuf;

#endif
    sso_snow3g_key_schedule_t *pKey = (sso_snow3g_key_schedule_t *)pHandle;
    sso_snow3gKeyState4_t ctx;
    __m128i H, L;  /* 4 bytes of keystream */
    uint32_t bytes1 = (lengthInBytes1 < lengthInBytes2 ? lengthInBytes1 : lengthInBytes2);  /* number of bytes */
    uint32_t bytes2 = (lengthInBytes3 < lengthInBytes4 ? lengthInBytes3 : lengthInBytes4);  /* number of bytes */
    uint32_t bytes = (bytes1 < bytes2) ? bytes1 : bytes2; /* min number of bytes */
    uint32_t qwords = bytes / SNOW3G_8_BYTES;
    bytes = qwords * SNOW3G_8_BYTES;  /* rounded down minimum length */

    /* Initialize the schedule from the IV */ 
    sso_snow3gStateInitialize_4(&ctx, pKey, pIV1, pIV2, pIV3, pIV4);

    /* Clock FSM and LFSR once, ignore the keystream */ 
    sso_snow3g_keystream_4_4(&ctx, &L);

    lengthInBytes1 -= bytes;
    lengthInBytes2 -= bytes;
    lengthInBytes3 -= bytes;
    lengthInBytes4 -= bytes;

    /* generates 4 bytes at a time on all streams */
    while (qwords--)
    {
        sso_snow3g_keystream_4_8(&ctx, &L, &H);

#if (defined(LINUX64))
        pBufferIn1 = sso_xor_keystrm_rev(pBufferOut1, pBufferIn1, _mm_extract_epi64(L, 0));
        pBufferIn2 = sso_xor_keystrm_rev(pBufferOut2, pBufferIn2, _mm_extract_epi64(L, 1));
        pBufferIn3 = sso_xor_keystrm_rev(pBufferOut3, pBufferIn3, _mm_extract_epi64(H, 0));
        pBufferIn4 = sso_xor_keystrm_rev(pBufferOut4, pBufferIn4, _mm_extract_epi64(H, 1));
#else
        /*  _mm_extract_epi64 is only x86_64, use a 32 bit variant */
        sso_xor_keystream_reverse_32(pBufferOut1+0, pBufferIn1+0, _mm_extract_epi32(L, 1));
        sso_xor_keystream_reverse_32(pBufferOut1+4, pBufferIn1+4, _mm_extract_epi32(L, 0));
        sso_xor_keystream_reverse_32(pBufferOut2+0, pBufferIn2+0, _mm_extract_epi32(L, 3));
        sso_xor_keystream_reverse_32(pBufferOut2+4, pBufferIn2+4, _mm_extract_epi32(L, 2));
        sso_xor_keystream_reverse_32(pBufferOut3+0, pBufferIn3+0, _mm_extract_epi32(H, 1));
        sso_xor_keystream_reverse_32(pBufferOut3+4, pBufferIn3+4, _mm_extract_epi32(H, 0));
        sso_xor_keystream_reverse_32(pBufferOut4+0, pBufferIn4+0, _mm_extract_epi32(H, 3));
        sso_xor_keystream_reverse_32(pBufferOut4+4, pBufferIn4+4, _mm_extract_epi32(H, 2));
        pBufferIn1 += SNOW3G_8_BYTES;
        pBufferIn2 += SNOW3G_8_BYTES;
        pBufferIn3 += SNOW3G_8_BYTES;
        pBufferIn4 += SNOW3G_8_BYTES;
#endif

        pBufferOut1 += SNOW3G_8_BYTES;
        pBufferOut2 += SNOW3G_8_BYTES;
        pBufferOut3 += SNOW3G_8_BYTES;
        pBufferOut4 += SNOW3G_8_BYTES;
    }

    /* process the remaining of each buffer
    *  - extract the LFSR and FSM structures
    *  - Continue process 1 buffer
    */
	if (lengthInBytes1 | lengthInBytes2 | lengthInBytes3 | lengthInBytes4){
		sso_snow3g_keystream_4_8(&ctx, &L, &H);
	} else return;
#if ( defined (_3GPP_SAFE_BUFFERS)) 
#if (defined(LINUX64))
	if (lengthInBytes1)
		(void)sso_xor_keystrm_rev(pBufferOut1, pBufferIn1, _mm_extract_epi64(L, 0));
	if (lengthInBytes2)
		(void)sso_xor_keystrm_rev(pBufferOut2, pBufferIn2, _mm_extract_epi64(L, 1));
	if (lengthInBytes3)
		(void)sso_xor_keystrm_rev(pBufferOut3, pBufferIn3, _mm_extract_epi64(H, 0));
	if (lengthInBytes4)
		(void)sso_xor_keystrm_rev(pBufferOut4, pBufferIn4, _mm_extract_epi64(H, 1));
#else
        /*  _mm_extract_epi64 is only x86_64, use a 32 bit variant */
	if (lengthInBytes1){
		sso_xor_keystream_reverse_32(pBufferOut1+0, pBufferIn1+0, _mm_extract_epi32(L, 1));
		sso_xor_keystream_reverse_32(pBufferOut1+4, pBufferIn1+4, _mm_extract_epi32(L, 0));
		}
	if (lengthInBytes2) {
		sso_xor_keystream_reverse_32(pBufferOut2+0, pBufferIn2+0, _mm_extract_epi32(L, 3));
		sso_xor_keystream_reverse_32(pBufferOut2+4, pBufferIn2+4, _mm_extract_epi32(L, 2));
		}
	if (lengthInBytes3) {
		sso_xor_keystream_reverse_32(pBufferOut3+0, pBufferIn3+0, _mm_extract_epi32(H, 1));
		sso_xor_keystream_reverse_32(pBufferOut3+4, pBufferIn3+4, _mm_extract_epi32(H, 0));
	}
	if (lengthInBytes4) {
		sso_xor_keystream_reverse_32(pBufferOut4+0, pBufferIn4+0, _mm_extract_epi32(H, 3));
        sso_xor_keystream_reverse_32(pBufferOut4+4, pBufferIn4+4, _mm_extract_epi32(H, 2));
	}
#endif /*LINUX64*/
#else
	#if (defined(LINUX64))
	if (lengthInBytes1) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn1, lengthInBytes1);
		(void)sso_xor_keystrm_rev(spBufferOut.b8, spBufferIn.b8, _mm_extract_epi64(L, 0));
		memcpy(pBufferOut1, spBufferOut.b8, lengthInBytes1);
	}
	if (lengthInBytes2) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn2, lengthInBytes2);
		(void)sso_xor_keystrm_rev(spBufferOut.b8, spBufferIn.b8, _mm_extract_epi64(L, 1));
		memcpy(pBufferOut2, spBufferOut.b8, lengthInBytes2);
	}
	if (lengthInBytes3){
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn3, lengthInBytes3);
		(void)sso_xor_keystrm_rev(spBufferOut.b8, spBufferIn.b8, _mm_extract_epi64(H, 0));
		memcpy(pBufferOut3, spBufferOut.b8, lengthInBytes3);
	}
	if (lengthInBytes4) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn4, lengthInBytes4);
		(void)sso_xor_keystrm_rev(spBufferOut.b8, spBufferIn.b8, _mm_extract_epi64(H, 1));
		memcpy(pBufferOut4, spBufferOut.b8, lengthInBytes4);
	}
#else
        /*  _mm_extract_epi64 is only x86_64, use a 32 bit variant */
	if (lengthInBytes1){
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn1, lengthInBytes1);
		sso_xor_keystream_reverse_32(spBufferOut.b8,spBufferIn.b8, _mm_extract_epi32(L, 1));
		sso_xor_keystream_reverse_32((uint8_t*)spBufferOut.b32[1],(uint8_t*)spBufferIn.b32[1], _mm_extract_epi32(L, 0));
		memcpy(pBufferOut1, spBufferOut.b8, lengthInBytes1);
		}
	if (lengthInBytes2) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn2, lengthInBytes2);
		sso_xor_keystream_reverse_32(spBufferOut.b8,spBufferIn.b8, _mm_extract_epi32(L, 3));
		sso_xor_keystream_reverse_32((uint8_t*)spBufferOut.b32[1],(uint8_t*)spBufferIn.b32[1], _mm_extract_epi32(L, 2));
		memcpy(pBufferOut2, spBufferOut.b8, lengthInBytes2);
		}
	if (lengthInBytes3) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn3, lengthInBytes3);
		sso_xor_keystream_reverse_32(spBufferOut.b8,spBufferIn.b8, _mm_extract_epi32(H, 1));
		sso_xor_keystream_reverse_32((uint8_t*)spBufferOut.b32[1],(uint8_t*)spBufferIn.b32[1], _mm_extract_epi32(H, 0));
		memcpy(pBufferOut3, spBufferOut.b8, lengthInBytes3);
	}
	if (lengthInBytes4) {
		SafeBuf spBufferOut, spBufferIn;
		memcpy(spBufferIn.b8, pBufferIn4, lengthInBytes4);
		sso_xor_keystream_reverse_32(spBufferOut.b8,spBufferIn.b8, _mm_extract_epi32(H, 3));
		sso_xor_keystream_reverse_32((uint8_t*)spBufferOut.b32[1],(uint8_t*)spBufferIn.b32[1], _mm_extract_epi32(H, 2));
		memcpy(pBufferOut4, spBufferOut.b8, lengthInBytes4);
	}
#endif /* LINUX64*/
#endif /*_3GPP_SAFE_BUFFERS*/
#endif /*SNOW3G_C*/
}

/*---------------------------------------------------------
* @description
* 	sso_snow3g_cpuid_check:
* 	Checks that the processor being used has 
*	capabilites defined in the top level Makefile.
*---------------------------------------------------------*/
uint32_t sso_snow3g_cpuid_check(void)
{
	unsigned a,b,c,d,ret = 0;

	asm volatile ("cpuid": "=a" (a), "=b" (b), "=c" (c), "=d" (d) : "a" (1));
	if(d & (1<<25))	  ret |= 1; 	/*SSE:EDX:25*/	
	if(d & (1<<26))   ret |= 2; 	/*SSE2:EDX:26*/	
	if(c & (1<<0)) 	  ret |= 4; 	/*SSE3:ECX:0*/	
	if(c & (1<<19))   ret |= 8; 	/*SSE4.1:ECX:19*/
    if(c & (1<<20))   ret |= 0x10;   /*SSE4.2:ECX:20*/
    if(c & (1<<28))   ret |= 0x20; 	/*AVX:ECX:28*/
	if(c & (1<<1))    ret |= 0x40; 	/*PCMULQDQ:ECX:1 */	
    return ret ^ 0x7F;
}



