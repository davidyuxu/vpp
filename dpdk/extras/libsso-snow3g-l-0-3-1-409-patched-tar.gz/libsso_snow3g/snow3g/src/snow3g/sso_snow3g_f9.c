/*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_SNOW3G.L.0.3.1-409
*
***************************************************************************/

#ifdef IACA
#include <iacaMarks.h>
#endif  
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "sso_snow3g.h"
#include "sso_snow3g_internal.h"


/*---------------------------------------------------------
* @description
* Gf2 modular multiplication/reduction
*
*---------------------------------------------------------*/

static inline uint64_t sso_multiply_and_reduce64(uint64_t a, uint64_t b)
{
    uint64_t res = 0;
#if 0
    uint64_t msk;
    uint64_t i = 64;

    while (i--)
        {
                msk  =   ((int64_t)res >> 63) & 0x1b;
                res  <<= 1;
                res  ^=  msk;
                msk  =   ((int64_t)b >> 63) & a;        
                b    <<= 1;
                res  ^=  msk;
        }
#else
  //c = a*b mod g in GF(2^64)
  //p(x)=c(x).x^64 mod g(x) = L(g*.M(c(x).q+(x)))
  //x^128 = g(x).q+(x) + p+(x)
  //g* = x^4+x^3+x+1, q+ = g = x^64+x^4+x^3+x+1
         __asm__("movq %1, %%xmm0 \n\t"
                "movq %2, %%xmm1 \n\t"
                "pclmulqdq $0, %%xmm1, %%xmm0 \n\t"
                "pextrq $1, %%xmm0, %%rax \n\t"
                "movq %%rax, %%rbx \n\t"
                "shr $60, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "shr $1, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "shr $2, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"

                "movq %%rax, %%rbx \n\t"
                "shl $1, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "shl $2, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "shl $1, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "movq %%xmm0, %%rbx \n\t"
                "xor %%rbx, %%rax \n\t"
                "movq %%rax, %0 \n\t"

                :"=r"(res)
                :"r"(a),"r"(b)
                :"%xmm0","%xmm1", "%rax", "%rbx");

#endif
	return res;
}


/*---------------------------------------------------------
* @description
* 	Snow3G F9 1 buffer
* 	Single buffer digest with IV and precomputed key schedule
*---------------------------------------------------------*/

void sso_snow3g_f9_1_buffer( sso_snow3g_key_schedule_t *pHandle,  uint8_t *pIV, uint8_t *pBufferIn, uint64_t lengthInBits, uint8_t *pDigest )
{
   	sso_snow3g_key_schedule_t *pKey = (sso_snow3g_key_schedule_t *)pHandle;
   	sso_snow3gKeyState1_t ctx;
	uint32_t z[5];	
	uint64_t lengthInQwords, E, V, P;
	uint64_t i, rem_bits;
	uint64_t *inputBuffer;

	inputBuffer = (uint64_t*) pBufferIn; 

   	/* Initialize the snow3g key schedule */ 
   	sso_snow3gStateInitialize_1(&ctx, pKey, pIV);

	/*Generate 5 keystream words*/
	sso_snow3g_f9_keystream_words(&ctx, &z[0]);

	P = ((uint64_t) z[0] << 32) | ((uint64_t) z[1]);

	lengthInQwords = lengthInBits / 64;

	E = 0;
	/* all blocks except the last one */
	for (i = 0; i < lengthInQwords; i++)
	{
		V = __builtin_bswap64(inputBuffer[i]);
		E = sso_multiply_and_reduce64(E ^ V, P);
	}

    /* last bits of last block if any left */
	rem_bits = lengthInBits % 64;
	if (rem_bits)
	{
#ifdef _3GPP_SAFE_BUFFERS
		V = __builtin_bswap64(inputBuffer[i]); // last bytes, and read up to 7 bytes past the end of buffer.
#else
		memcpy(&V, &inputBuffer[i], (rem_bits + 7)/8);  // last bytes, do not go past end of buffer 
		V = __builtin_bswap64(V); 
#endif
		V &= (((uint64_t)-1)<<(64 - rem_bits));      // mask extra bits
		E = sso_multiply_and_reduce64(E ^ V, P);
	}

	/* Multiply by Q */
	E = sso_multiply_and_reduce64(E ^ lengthInBits, (((uint64_t) z[2] << 32) | ((uint64_t) z[3])));

	/* Final MAC */
	*(uint32_t *)pDigest = (uint32_t)__builtin_bswap64(E ^ ((uint64_t) z[4] << 32) );

}

