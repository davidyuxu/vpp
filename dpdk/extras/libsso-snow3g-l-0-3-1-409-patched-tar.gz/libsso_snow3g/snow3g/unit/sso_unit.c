/***************************************************************************:
 *
 * INTEL CONFIDENTIAL
 * Copyright 2009-2013 Intel Corporation All Rights Reserved.
 * 
 * The source code contained or described herein and all documents related to the
 * source code ("Material") are owned by Intel Corporation or its suppliers or
 * licensors. Title to the Material remains with Intel Corporation or its
 * suppliers and licensors. The Material may contain trade secrets and proprietary
 * and confidential information of Intel Corporation and its suppliers and
 * licensors, and is protected by worldwide copyright and trade secret laws and
 * treaty provisions. No part of the Material may be used, copied, reproduced,
 * modified, published, uploaded, posted, transmitted, distributed, or disclosed
 * in any way without Intels prior express written permission.
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 * 
 * Include any supplier copyright notices as supplier requires Intel to use.
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * preceded by an asterisk.
 * An asterisked footnote can be added as follows: 
 *   *Third Party trademarks are the property of their respective owners.
 * 
 * Unless otherwise agreed by Intel in writing, you may not remove or alter this
 * notice or any other notice embedded in Materials by Intel or Intels suppliers
 * or licensors in any way.
 * 
 *  version: LIBSSO_SNOW3G.L.0.3.1-409
 *
 ***************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "sso_snow3g.h"
#include "sso_snow3g_internal.h"
#include "sso_test_vectors.h"
#include "sso_common.h"
#include "sso_utils.h"

#define SNOW3GIVLEN 8
cipher_test_vector_t*  vecList[MAX_DATA_LEN];

int validate_sso_snow3g_f8_1_block(void);
int validate_sso_snow3g_f8_2_block(void);
int validate_sso_snow3g_f8_4_blocks(void);
int validate_sso_snow3g_f8_n_blocks(void);
int validate_sso_snow3g_f9(void);
int membitcmp(const uint8_t* input,  const uint8_t* output, const uint32_t bitlength, const uint32_t offset);

int validate_sso_snow3g_f8_1_block(void)
{
	int numVectors,i,length, size = 0;
	cipher_test_vector_t* testVectors = cipher_test_vectors[1];
	/* snow3g f8  test vectors are located at index 1 */
	numVectors = numCipherTestVectors[1];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t srcBuff[MAX_DATA_LEN];
	uint8_t dstBuff[MAX_DATA_LEN];
	uint8_t *pIV;

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}

	pIV = malloc(SNOW3G_IV_LEN_IN_BYTES);
	if(!pIV){
		printf("malloc(pIV):failed ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(pKey):failed ! \n");
		return 1;
	}
	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}

	/*Copy the data for for Snow3g 1 Packet version*/
	for(i=0; i< numVectors; i++){

		length = testVectors[i].dataLenInBytes;

		memcpy(pKey,
				testVectors[i].key,
				testVectors[i].keyLenInBytes);
		memcpy(srcBuff,
				testVectors[i].plaintext,
				length);

		memcpy(dstBuff,
				testVectors[i].ciphertext,
				length);
		memcpy(pIV,
				testVectors[i].iv,
				testVectors[i].ivLenInBytes);

		/*setup the keysched to be used*/
		if(sso_snow3g_init_key_sched(pKey, pKeySched) == -1){
			printf("CPU check failed \n");
			free(pKey);
			free(pKeySched);
			return 1;
		}

		/*Validate Encrpyt*/
		sso_snow3g_f8_1_buffer(pKeySched, pIV, srcBuff, srcBuff, length);

		/*check against the cipher test in the vector against the encrypted plaintext*/
		if (memcmp (srcBuff,  dstBuff, length) !=0)
		{
			printf("sso_snow3g_f8_1_buffer(Enc)  vector:%d \n", i);
			sso_hexdump("Actual:", srcBuff, length);
			sso_hexdump("Expected:", dstBuff, length);
			free(pKey);
			free(pKeySched);
			return 1;
		}

		memcpy(dstBuff, testVectors[i].plaintext, length);

		/*Validate Decrpyt*/
		sso_snow3g_f8_1_buffer(pKeySched, pIV, srcBuff, srcBuff, length);

		if (memcmp (srcBuff,  dstBuff, length) !=0)
		{
			printf("sso_snow3g_f8_1_buffer(Dec)  vector:%d \n", i);
			sso_hexdump("Actual:", srcBuff, length);
			sso_hexdump("Expected:", dstBuff, length);
			free(pKey);
			free(pKeySched);
			return 1;
		}
	} //for numVectors

	free(pKey);
	free(pKeySched);
	printf("[%s]:  PASS, for %d single buffers. \n", __FUNCTION__, i);
	return 0;
}

/* Shift right a buffer by "offset" bits, "offset" < 8 */
static void buffer_shift_right(uint8_t *buffer, uint32_t length, uint8_t offset)
{
	uint8_t curr_byte, prev_byte;
	uint32_t length_in_bytes = (length * 8 + offset + 7)/8;
	uint8_t lower_byte_mask = (1 << offset) - 1;
	unsigned i;

	prev_byte = buffer[0];
	buffer[0] >>= offset;

	for (i = 1; i < length_in_bytes; i++) {
		curr_byte = buffer[i];
		buffer[i] = ((prev_byte & lower_byte_mask) << (8 - offset)) |(curr_byte >> offset);
		prev_byte = curr_byte;
	}
}

int validate_sso_snow3g_f8_1_bitblock(void)
{
	int numVectors, i, length, size = 0;
	cipherbit_test_linear_vector_t* testVectors = &snow3g_f8_linear_bitvectors/*cipher_test_vectors[1]*/;
	cipher_test_vector_t* testStandardVectors = snow3g_f8_vectors;//scipher_test_vectors[1];
	/* snow3g f8  test vectors are located at index 1 */
	numVectors =  MAX_BIT_BUFFERS;//numCipherTestVectors[3];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t srcBuff[MAX_DATA_LEN];
	uint8_t midBuff[MAX_DATA_LEN];
	uint8_t dstBuff[MAX_DATA_LEN];
	uint8_t *pIV;
	uint32_t bufferbytesize = 0;
	uint32_t offset = 0;
	uint32_t byteoffset = 0;

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}
	for (i=0; i< numVectors; i++){
		bufferbytesize += testVectors->dataLenInBits[i];
	}
	bufferbytesize = (bufferbytesize +7)/8;
	pIV = malloc(SNOW3G_IV_LEN_IN_BYTES);
	if(!pIV){
		printf("malloc(pIV):failed ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(pKey):failed ! \n");
		return 1;
	}
	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}
	memcpy(srcBuff,
		testVectors->plaintext,
		bufferbytesize);

	memcpy(dstBuff,
		testVectors->ciphertext,
		bufferbytesize);

	/*Copy the data for for Snow3g 1 Packet version*/
	for(i=0, offset = 0, byteoffset = 0; i< numVectors; i++){

		memcpy(pKey,
				testVectors->key[i],
				testVectors->keyLenInBytes);
		memcpy(pIV,
				testVectors->iv[i],
				testVectors->ivLenInBytes);

		/*setup the keysched to be used*/
		if(sso_snow3g_init_key_sched(pKey, pKeySched) == -1){
			printf("CPU check failed \n");
			free(pKey);
			free(pKeySched);
			return 1;
		}

		/*Validate Encrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, srcBuff, midBuff, testVectors->dataLenInBits[i], offset);

		/*check against the cipher test in the vector against the encrypted plaintext*/
		if (membitcmp (midBuff,  dstBuff, testVectors->dataLenInBits[i], offset) !=0)
		{
			printf("Test1: sso_snow3g_f8_1_bitbuffer(Enc) buffer:%d size:%d  offset:%d \n", i, testVectors->dataLenInBits[i], offset);
			sso_hexdump("Actual:", &midBuff[byteoffset], (testVectors->dataLenInBits[i]+7)/8);
			sso_hexdump("Expected:", &dstBuff[byteoffset], (testVectors->dataLenInBits[i]+7)/8);
			free(pKey);
			free(pKeySched);
			return 1;
		}


		/*Validate Decrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, /*midBuff*/dstBuff, midBuff/*dstBuff*/, testVectors->dataLenInBits[i], offset);

		if (membitcmp (midBuff/*dstBuff*/,  srcBuff, testVectors->dataLenInBits[i], offset) !=0)
		{
			printf("Test2: sso_snow3g_f8_1_bitbuffer(Dec) buffer:%d  size:%d offset:%d \n", i, testVectors->dataLenInBits[i], offset);
			sso_hexdump("Actual:", &/*dstBuff*/midBuff[byteoffset], (testVectors->dataLenInBits[i]+ offset%8 + 7)/8);
			sso_hexdump("Expected:", &srcBuff[byteoffset], (testVectors->dataLenInBits[i]+offset%8 + 7)/8);
			free(pKey);
			free(pKeySched);
			return 1;
		}
		/* Another test with Standard 3GPP table */
		length = testStandardVectors[i].dataLenInBytes;
		memcpy(srcBuff,
			testStandardVectors[i].plaintext,
			length);

		memcpy(dstBuff,
			testStandardVectors[i].ciphertext,
			length);

		/*Validate Encrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, srcBuff, midBuff, testStandardVectors[i].dataLenInBytes * 8, 0);

		/*check against the cipher test in the vector against the encrypted plaintext*/
		if (membitcmp (midBuff,  dstBuff, testStandardVectors[i].dataLenInBytes * 8, 0) !=0)
		{
			printf("Test3: sso_snow3g_f8_1_bitbuffer(Enc) buffer:%d size:%d offset:0\n", i, testStandardVectors[i].dataLenInBytes * 8);
			sso_hexdump("Actual:", &midBuff[0], testStandardVectors[i].dataLenInBytes);
			sso_hexdump("Expected:", &dstBuff[0], testStandardVectors[i].dataLenInBytes);
			free(pKey);
			free(pKeySched);
			return 1;
		}


		/*Validate Decrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, midBuff, dstBuff, testStandardVectors[i].dataLenInBytes * 8, 0);

		if (membitcmp (dstBuff,  srcBuff, testStandardVectors[i].dataLenInBytes * 8, 0) !=0)
		{
			printf("Test4: sso_snow3g_f8_1_bitbuffer(Dec) buffer:%d size:%d offset:0\n", i, testStandardVectors[i].dataLenInBytes * 8);
			sso_hexdump("Actual:", &dstBuff[0], testStandardVectors[i].dataLenInBytes);
			sso_hexdump("Expected:", &srcBuff[0], testStandardVectors[i].dataLenInBytes);
			free(pKey);
			free(pKeySched);
			return 1;
		}
		memcpy(srcBuff,
			testStandardVectors[i].plaintext,
			length);

		memcpy(dstBuff,
			testStandardVectors[i].ciphertext,
			length);

		buffer_shift_right(srcBuff,  testStandardVectors[i].dataLenInBytes, 4);
		buffer_shift_right(dstBuff,  testStandardVectors[i].dataLenInBytes, 4);

		/*Validate Encrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, srcBuff, midBuff, testStandardVectors[i].dataLenInBytes * 8, 4);

		/*check against the cipher test in the vector against the encrypted plaintext*/
		if (membitcmp (midBuff,  dstBuff, testStandardVectors[i].dataLenInBytes * 8, 4) !=0)
		{
			printf("Test5:sso_snow3g_f8_1_bitbuffer(Enc) buffer:%d size:%d offset:4\n", i, testStandardVectors[i].dataLenInBytes * 8);
			sso_hexdump("Actual:", &midBuff[0], (testStandardVectors[i].dataLenInBytes * 8 +4 +7)/8);
			sso_hexdump("Expected:", &dstBuff[0], (testStandardVectors[i].dataLenInBytes * 8 +4 +7)/8);
			free(pKey);
			free(pKeySched);
			return 1;
		}


		/*Validate Decrpyt*/
		sso_snow3g_f8_1_buffer_bit(pKeySched, pIV, /*midBuff*/dstBuff, /*dstBuff*/midBuff, testStandardVectors[i].dataLenInBytes * 8, 4);

		if (membitcmp (midBuff/*dstBuff*/,  srcBuff, testStandardVectors[i].dataLenInBytes * 8, 4) !=0)
		{
			printf("Test6: sso_snow3g_f8_1_bitbuffer(Dec) buffer:%d size:%d offset:4\n", i, testStandardVectors[i].dataLenInBytes * 8);
			sso_hexdump("Actual:", &dstBuff[0], (testStandardVectors[i].dataLenInBytes * 8 + 4 +7)/8);
			sso_hexdump("Expected:", &srcBuff[0], (testStandardVectors[i].dataLenInBytes * 8 + 4 +7)/8);
			free(pKey);
			free(pKeySched);
			return 1;
		}
		memcpy(srcBuff,
			testVectors->plaintext,
			bufferbytesize);

		memcpy(dstBuff,
			testVectors->ciphertext,
			bufferbytesize);
		memcpy(midBuff,
			testVectors->ciphertext,
			bufferbytesize);


		offset +=  testVectors->dataLenInBits[i];
		byteoffset = offset/8;
	} //for numVectors

	free(pKey);
	free(pKeySched);
	printf("[%s]:  PASS, for %d single buffers. \n", __FUNCTION__, i);
	return 0;
}
int validate_sso_snow3g_f8_2_blocks(void)
{
	int length,numVectors,i,j,size = 0, numPackets=2;
	cipher_test_vector_t* testVectors = cipher_test_vectors[1];
	/* snow3g f8  test vectors are located at index 1 */
	numVectors = numCipherTestVectors[1];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t *srcBuff[numPackets];
	uint8_t *dstBuff[numPackets];
	uint8_t *IV[SNOW3G_IV_LEN_IN_BYTES];
	uint32_t packetLen[numPackets];

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(key):failed ! \n");
		return 1;
	}

	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}

	/* Test with all vectors */
	for (j = 0; j < numVectors; j++) {
		length = testVectors[j].dataLenInBytes;
	
		/*	Create test Data for num Packets*/
		for(i=0; i< numPackets; i++){
	
			packetLen[i] = length;
			srcBuff[i] = malloc(length);
			dstBuff[i] = malloc(length);
			IV[i] = malloc(SNOW3G_IV_LEN_IN_BYTES);
	
			memcpy(pKey,
					testVectors[j].key,
					testVectors[j].keyLenInBytes);
	
			memcpy(srcBuff[i],
					testVectors[j].plaintext,
					length);
	
			memset(dstBuff[i], 0, length);
	
			memcpy(IV[i],
					testVectors[j].iv,
					testVectors[j].ivLenInBytes);
		}
	
		/*only 1 key is needed for snow3g 2 blocks*/
		if(sso_snow3g_init_key_sched(pKey, pKeySched)){
				printf("sso_snow3g_init_key_sched()error \n");
				free(pKey);
				free(pKeySched);
				return 1;
		}

		/* TEST IN-PLACE ENCRYPTION/DECRYPTION */	
		/*Test the encrypt*/
		sso_snow3g_f8_2_buffer(pKeySched, IV[0], IV[1], srcBuff[0], srcBuff[0], packetLen[0], srcBuff[1], srcBuff[1], packetLen[1]);
	
		/*compare the cipher text with the encryped plain text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (srcBuff[i], testVectors[j].ciphertext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_2_buffer(Enc)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", srcBuff[i], packetLen[0]);
				sso_hexdump("Expected:", testVectors[j].ciphertext, packetLen[0]);
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
	
		/* Set the source buffer with ciphertext, and clear destination buffer */	
		for(i=0; i< numPackets; i++){
			memcpy(srcBuff[i],
					testVectors[j].ciphertext,
					length);
		}

		/*Test the decrypt*/
		sso_snow3g_f8_2_buffer(pKeySched, IV[0], IV[1], srcBuff[0], srcBuff[0], packetLen[0], srcBuff[1], srcBuff[1], packetLen[1]);
	
		/*Compare the plaintext with the decrypted cipher text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (srcBuff[i], testVectors[j].plaintext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_2_buffer(Dec)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", srcBuff[i], packetLen[0]);
				sso_hexdump("Expected:", testVectors[j].plaintext, packetLen[i]);
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
	
		/* TEST OUT-OF-PLACE ENCRYPTION/DECRYPTION */	
		/*Test the encrypt*/
		sso_snow3g_f8_2_buffer(pKeySched, IV[0], IV[1], srcBuff[0], dstBuff[0], packetLen[0], srcBuff[1], dstBuff[1], packetLen[1]);
	
		/*compare the cipher text with the encryped plain text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (dstBuff[i], testVectors[j].ciphertext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_2_buffer(Enc)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", dstBuff[i], packetLen[0]);
				sso_hexdump("Expected:", testVectors[j].ciphertext, packetLen[0]);
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
		/* Set the source buffer with ciphertext, and clear destination buffer */	
		for(i=0; i< numPackets; i++){
			memcpy(srcBuff[i],
					testVectors[j].ciphertext,
					length);
	
			memset(dstBuff[i], 0, length);
		}
	
		/*Test the decrypt*/
		sso_snow3g_f8_2_buffer(pKeySched, IV[0], IV[1], srcBuff[0], dstBuff[0], packetLen[0], srcBuff[1], dstBuff[1], packetLen[1]);
	
		/*Compare the plaintext with the decrypted cipher text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (dstBuff[i], testVectors[j].plaintext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_2_buffer(Dec)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", dstBuff[i], packetLen[0]);
				sso_hexdump("Expected:", testVectors[j].plaintext, packetLen[i]);
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
	}

	printf("[%s]:  PASS, for %d single buffers. \n", __FUNCTION__, i);
	return 0;
}

int validate_sso_snow3g_f8_4_blocks()
{
	int length,numVectors,i,j,size=0, numPackets=4;
	cipher_test_vector_t* testVectors = cipher_test_vectors[1];
	/* snow3g f8  test vectors are located at index 1 */
	numVectors = numCipherTestVectors[1];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t *srcBuff[numPackets];
	uint8_t *dstBuff[numPackets];
	uint8_t *IV[SNOW3G_IV_LEN_IN_BYTES];
	uint32_t packetLen[numPackets];

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(key):failed ! \n");
		return 1;
	}

	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}

	/* Test with all vectors */
	for (j = 0; j < numVectors; j++) {
		/*vectors are in bits used to round up to bytes*/
		length = testVectors[j].dataLenInBytes;
	
		/*	Create test Data for num Packets*/
		for(i=0; i< numPackets; i++){
	
			packetLen[i] = length;
			srcBuff[i] = malloc(length);
			dstBuff[i] = malloc(length);
			IV[i] = malloc(SNOW3G_IV_LEN_IN_BYTES);
	
			memcpy(pKey,
					testVectors[j].key,
					testVectors[j].keyLenInBytes);
	
			memcpy(srcBuff[i],
					testVectors[j].plaintext,
					length);
	
			memset(dstBuff[i], 0, length);
	
			memcpy(IV[i],
					testVectors[j].iv,
					testVectors[j].ivLenInBytes);
		}
	
		/*only 1 key is needed for snow3g 4 blocks*/
		if(sso_snow3g_init_key_sched(pKey, pKeySched)){
				printf("sso_snow3g_init_key_sched()error \n");
				free(pKey);
				free(pKeySched);
				return 1;
		}
	
		/* TEST IN-PLACE ENCRYPTION/DECRYPTION */	
		/*Test the encrypt*/
		sso_snow3g_f8_4_buffer(pKeySched, IV[0], IV[1], IV[2], IV[3], srcBuff[0], srcBuff[0], packetLen[0],
				srcBuff[1], srcBuff[1], packetLen[1], srcBuff[2], srcBuff[2], packetLen[2], srcBuff[3], srcBuff[3], packetLen[3]);

		/*compare the cipher text with the encryped plain text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (srcBuff[i], testVectors[j].ciphertext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_4_buffer(Enc)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", srcBuff[i], packetLen[i]);
				sso_hexdump("Expected:", testVectors[j].ciphertext, packetLen[i]);
				for (i = 0; i < numPackets; i++) {
					if (NULL != srcBuff[i])free(srcBuff[i]);
					if (NULL != dstBuff[i])free(dstBuff[i]);
					if (NULL != IV[i]) free(IV[i]);
				}
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}

		/* Set the source buffer with ciphertext, and clear destination buffer */	
		for(i=0; i< numPackets; i++){
			memcpy(srcBuff[i],
					testVectors[j].ciphertext,
					length);
		}

		/*Test the decrypt*/
		sso_snow3g_f8_4_buffer(pKeySched, IV[0], IV[1], IV[2], IV[3], srcBuff[0], srcBuff[0], packetLen[0],
				srcBuff[1], srcBuff[1], packetLen[1], srcBuff[2], srcBuff[2], packetLen[2], srcBuff[3], srcBuff[3], packetLen[3]);
	
		/*Compare the plaintext with the decrypted cipher text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (srcBuff[i], testVectors[j].plaintext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_4_buffer(Dec)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", srcBuff[i], packetLen[i]);
				sso_hexdump("Expected:", testVectors[j].plaintext, packetLen[i]);
				free(pKey);
				free(pKeySched);
				for (i = 0; i < numPackets; i++) {
					if (NULL != srcBuff[i])free(srcBuff[i]);
					if (NULL != dstBuff[i])free(dstBuff[i]);
					if (NULL != IV[i]) free(IV[i]);
				}
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
		/* TEST OUT-OF-PLACE ENCRYPTION/DECRYPTION */	
		/*Test the encrypt*/
		sso_snow3g_f8_4_buffer(pKeySched, IV[0], IV[1], IV[2], IV[3], srcBuff[0], dstBuff[0], packetLen[0],
				srcBuff[1], dstBuff[1], packetLen[1], srcBuff[2], dstBuff[2], packetLen[2], srcBuff[3], dstBuff[3], packetLen[3]);

		/*compare the cipher text with the encryped plain text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (dstBuff[i], testVectors[j].ciphertext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_4_buffer(Enc)  vector:%d \n", j);
				sso_hexdump("Actual:", dstBuff[i], packetLen[i]);
				sso_hexdump("Expected:", testVectors[j].ciphertext, packetLen[i]);
				free(pKey);
				free(pKeySched);
				for (i = 0; i < numPackets; i++) {
					if (NULL != srcBuff[i])free(srcBuff[i]);
					if (NULL != dstBuff[i])free(dstBuff[i]);
					if (NULL != IV[i]) free(IV[i]);
				}
				return 1;
			}
		}
	
		/* Set the source buffer with ciphertext, and clear destination buffer */	
		for(i=0; i< numPackets; i++){
			memcpy(srcBuff[i],
					testVectors[j].ciphertext,
					length);
	
			memset(dstBuff[i], 0, length);
		}
		/*Test the decrypt*/
		sso_snow3g_f8_4_buffer(pKeySched, IV[0], IV[1], IV[2], IV[3], srcBuff[0], dstBuff[0], packetLen[0],
				srcBuff[1], dstBuff[1], packetLen[1], srcBuff[2], dstBuff[2], packetLen[2], srcBuff[3], dstBuff[3], packetLen[3]);
	
		/*Compare the plaintext with the decrypted cipher text*/
		for(i=0; i<numPackets; i++){
			if (memcmp (dstBuff[i], testVectors[j].plaintext, packetLen[i]) !=0)
			{
				printf("sso_snow3g_f8_4_buffer(Dec)  vector:%d buffer:%d\n", j, i);
				sso_hexdump("Actual:", dstBuff[i], packetLen[i]);
				sso_hexdump("Expected:", testVectors[j].plaintext, packetLen[i]);
				for (i = 0; i < numPackets; i++) {
					if (NULL != srcBuff[i]) free(srcBuff[i]);
					if (NULL != dstBuff[i]) free(dstBuff[i]);
					if (NULL != IV[i]) free(IV[i]);
				}
				free(pKey);
				free(pKeySched);
				return 1;
			}
		}
	}
	printf("[%s]:  PASS, for %d single buffers. \n", __FUNCTION__, i);
	for (i = 0; i < numPackets; i++) {
		if (NULL != srcBuff[i]) free(srcBuff[i]);
		if (NULL != dstBuff[i]) free(dstBuff[i]);
		if (NULL != IV[i]) free(IV[i]);
	}
	free(pKey);
	free(pKeySched);
	return 0;
}

int validate_sso_snow3g_f8_n_blocks(void)
{
	int length,numVectors,i, size = 0, numPackets=16;
	cipher_test_vector_t* testVectors = cipher_test_vectors[1];
	/* snow3g f8  test vectors are located at index 1 */
	numVectors = numCipherTestVectors[1];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t *srcBuff[NUM_SUPPORTED_BUFFERS];
	uint8_t *dstBuff[NUM_SUPPORTED_BUFFERS];
	uint8_t *IV[NUM_SUPPORTED_BUFFERS];
	uint32_t packetLen[numPackets];

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(key):failed ! \n");
		return 1;
	}

	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}

	/*vectors are in bits used to round up to bytes*/
	length = testVectors[0].dataLenInBytes;

	/*	Create test Data for num Packets*/
	for(i=0; i< numPackets; i++){

		packetLen[i] = length;
		srcBuff[i] = malloc(length);
		dstBuff[i] = malloc(length);
		IV[i] = malloc(SNOW3G_IV_LEN_IN_BYTES);

		memcpy(pKey,
				testVectors[0].key,
				testVectors[0].keyLenInBytes);

		memcpy(srcBuff[i],
				testVectors[0].plaintext,
				length);

		memcpy(dstBuff[i],
				testVectors[0].ciphertext,
				length);

		memcpy(IV[i],
				testVectors[0].iv,
				testVectors[0].ivLenInBytes);
	}
	


		if(sso_snow3g_init_key_sched(pKey, pKeySched)){
			printf("sso_snow3g_init_key_sched()error \n");
			for(i=0; i < numPackets; i++){
				if (NULL != srcBuff[i]) free(srcBuff[i]);
				if (NULL != dstBuff[i]) free(dstBuff[i]);
				if (NULL != IV[i]) free(IV[i]);
			}
			free(pKey);
			free(pKeySched);
			return 1;
		}

	for(i = 0; i < NUM_SUPPORTED_BUFFERS; i++)
	{
		/*Test the encrypt*/
		sso_snow3g_f8_n_buffer(pKeySched, IV, srcBuff, dstBuff, packetLen, i+1);
		/*Compare the data in the dstBuff with the cipher pattern*/
		if (memcmp (testVectors[0].ciphertext, dstBuff[i], packetLen[i]) !=0)
		{
			printf("sso_snow3g_f8_n_buffer(Enc) , vector:%d \n", i);
			sso_hexdump("Actual:", dstBuff[i], packetLen[0]);
			sso_hexdump("Expected:", testVectors[0].ciphertext, packetLen[0]);
			for(i=0; i< numPackets; i++){
				if (NULL != srcBuff[i]) free(srcBuff[i]);
				if (NULL != dstBuff[i]) free(dstBuff[i]);
				if (NULL != IV[i]) free(IV[i]);
			}
			free(pKeySched);
			free(pKey);
			return 1;
		}
		/*Test the Decrypt*/
		sso_snow3g_f8_n_buffer(pKeySched, IV, dstBuff, srcBuff, packetLen, i+1);

		/*Compare the data in the srcBuff with the dstBuff*/
		if (memcmp (srcBuff[i], testVectors[0].plaintext, packetLen[i]) !=0)
		{
			printf("sso_snow3g_f8_n_buffer equal sizes, vector:%d \n", i);
			sso_hexdump("Actual:", srcBuff[i], packetLen[i]);
			sso_hexdump("Expected:", testVectors[0].plaintext, packetLen[0]);
			for(i=0; i< numPackets; i++){
				if (NULL != srcBuff[i]) free(srcBuff[i]);
				if (NULL != dstBuff[i]) free(dstBuff[i]);
				if (NULL != IV[i]) free(IV[i]);
		}
			free(pKeySched);
			free(pKey);
			return 1;
		}
	}
	for(i=0; i< numPackets; i++){
		if (NULL != srcBuff[i]) free(srcBuff[i]);
		if (NULL != dstBuff[i]) free(dstBuff[i]);
		if (NULL != IV[i]) free(IV[i]);
	}
	free(pKeySched);
	free(pKey);
	printf("[%s]: PASS. \n", __FUNCTION__);
	return 0;
}

int validate_sso_snow3g_f9(void)
{
	int numVectors,i, inputLen, size = 0;
	hash_test_vector_t* testVectors = hash_test_vectors[2];
	/* snow3g f9  test vectors are located at index 2 */
	numVectors = numHashTestVectors[2];

	sso_snow3g_key_schedule_t *pKeySched = NULL;
	uint8_t* pKey = NULL;
	int keyLen = MAX_KEY_LEN;
	uint8_t srcBuff[MAX_DATA_LEN];
	uint8_t digest[KASUMI_DIGEST_LEN];
	uint8_t *pIV;

	if(!numVectors){
		printf("No Snow3G test vectors found ! \n");
		return 1;
	}

	pIV = malloc(SNOW3G_IV_LEN_IN_BYTES);
	if(!pIV){
		printf("malloc(pIV):failed ! \n");
		return 1;
	}

	pKey = malloc(keyLen);
	if(!pKey){
		printf("malloc(pKey):failed ! \n");
		return 1;
	}
	size = sso_snow3g_key_sched_size();
	if(!size) {
		return -1;
	}

	pKeySched = malloc(size);
	if(!pKeySched){
		printf("malloc(sso_snow3g_key_sched_size()): failed ! \n");
		free(pKey);
		return 1;
	}

	/*Get test data for for Snow3g 1 Packet version*/
	for(i=0; i< numVectors; i++)
	{
		//printf("[%s] Start 3GPP test set: %d \n", __FUNCTION__, i+1);

		inputLen = (testVectors[i].lengthInBits+7)/8;

		memcpy(pKey,
				testVectors[i].key,
				testVectors[i].keyLenInBytes);
		memcpy(srcBuff,
				testVectors[i].input,
				inputLen);
		memcpy(pIV,
				testVectors[i].iv,
				testVectors[i].ivLenInBytes);

		/*Only 1 key sched is used*/
		if(sso_snow3g_init_key_sched(pKey, pKeySched)){
			printf("sso_kasumi_init_f9_key_sched()error \n");
			free(pKey);
			free(pKeySched);
			return 1;
		}

		/*test the integrity for f9_user with IV*/
		sso_snow3g_f9_1_buffer(pKeySched, pIV, srcBuff, testVectors[i].lengthInBits, digest);

		/*Compare the digest with the expected in the vectors*/
		if(memcmp(digest, testVectors[i].exp_out, KASUMI_DIGEST_LEN) !=0)
		{
			printf("sso_snow3g_f9_1_buffer()  vector num:%d \n", i);
			sso_hexdump("Actual:", digest, KASUMI_DIGEST_LEN);
			sso_hexdump("Expected:", testVectors[i].exp_out, KASUMI_DIGEST_LEN);
			free(pKey);
			free(pKeySched);
			return 1;
		}

	} //for numVectors
	free(pKey);
	free(pKeySched);
	printf("[%s]:		  PASS, for %d single buffers. \n", __FUNCTION__, i);
	return 0;
}


int main (int argc, char ** argv)
{
	int status=0;
	char cpuInfo[29];
	cpuInfo[0] = 0;
	//	Check CPU capabilities
	if( (status = sso_snow3g_cpuid_check()) ){
		if (!(status & 1)){
			strcat(cpuInfo,"SSE ");
		} else if (!(status & 2)){
			strcat(cpuInfo,"SSE2 ");
		} else if (!(status & 4)){
			strcat(cpuInfo,"SSE3 ");
		} else if (!(status & 8)){
			strcat(cpuInfo,"SSE4.1 ");
		} else if (!(status & 0x10)){
			strcat(cpuInfo,"SSE4.2 ");
		} else if (!(status & 0x20)){
			strcat(cpuInfo,"AVX ");
		} else if (!(status & 0x40)){
			strcat(cpuInfo,"PCMUL");
		} else {
			strcat(cpuInfo,"NO");
		}
		printf("sso_snow3G_cpuid_check(): INFO: %s flags unsupported\n", cpuInfo);
	}

	status = 0;
#if 1
	if(validate_sso_snow3g_f8_1_block())
	{
		printf("validate_sso_snow3g_f8_1_block: FAIL\n");
		status=1;
	}
#endif
#if 1
	if(validate_sso_snow3g_f8_1_bitblock())
	{
		printf("validate_sso_snow3g_f8_1_bitblock: FAIL\n");
		status=1;
	}
#endif
#if 1
	if(validate_sso_snow3g_f8_2_blocks())
	{
		printf("validate_sso_snow3g_f8_2_blocks: FAIL\n");
		status=1;
	}
#endif
#if 1
	if(validate_sso_snow3g_f8_4_blocks())
	{
		printf("validate_sso_snow3g_f8_4_blocks: FAIL\n");
		status=1;
	}
#endif
#if defined(LINUX64)
#if 1
	if(validate_sso_snow3g_f8_n_blocks())
	{
		printf("validate_sso_snow3g_f8_n_blocks: FAIL\n");
		status=1;
	}
#endif
#endif
#if 1
	if(validate_sso_snow3g_f9())
	{
		printf("validate_sso_snow3g_f9: FAIL\n");
		status=1;
	}
#endif
	if(!status)
		printf("ALL TESTS PASSED. \n");
	else
		printf("WE HAVE TEST FAILURES ! \n");

	return 0;
}
int membitcmp(const uint8_t* input,  const uint8_t* output, const uint32_t bitlength, const uint32_t bitoffset)
{
	uint32_t bitresoffset;
	uint8_t bitresMask = ~((uint8_t)-1 << ( 8 - (bitoffset%8)));
	uint32_t res;
	uint32_t bytelengthfl = bitlength/8;
	const uint8_t* srcfl = input + bitoffset/8;
	const uint8_t* dstfl = output + bitoffset/8;
	int index = 1;
	if (bitoffset % 8) {
		if ((*srcfl ^ *dstfl) & bitresMask) {
			return 1;

		} else {
			//bytelengthfl--;
			srcfl++;
			dstfl++;
		}
	}
	bitresoffset =  (bitlength + bitoffset)%8;
	while(bytelengthfl--) {
	res = *srcfl++ ^ *dstfl++;
		if(res) break;
		index++;
	}
	if ((bitresoffset) && (0 == bytelengthfl)) {
		res &= (uint8_t)-1 << (8 - bitresoffset);
		if(res) return index;
	}
return res;
}

