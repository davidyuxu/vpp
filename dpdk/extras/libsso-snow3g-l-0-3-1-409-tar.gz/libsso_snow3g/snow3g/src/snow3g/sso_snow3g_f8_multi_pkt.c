/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_SNOW3G.L.0.3.1-409
*
***************************************************************************/

/*-------------------------------------------------------------------
* Snow3G F8 Multi packet - Confidentiality Algorithm
*-------------------------------------------------------------------
*
* An example implementation of Snow3G F8 Multi packet.
*
*-------------------------------------------------------------------*/

#ifdef IACA
#include <iacaMarks.h>
#endif
#include "sso_snow3g.h"
#include "sso_snow3g_internal.h"

/******************************************************************************
* @description
*   Snow3G F8 multi packet:
*	Performs F8 enc/dec on [n] packets. The operation is performed in-place.
*	The input IV's are passed in Little Endian format.
*	The KeySchedule is in Little Endian format.
*******************************************************************************/

void sso_snow3g_f8_n_buffer(sso_snow3g_key_schedule_t *pCtx,
							uint8_t* IV[],
							uint8_t* pBufferIn[],
							uint8_t* pBufferOut[],
							uint32_t bufferLenInBytes[],
							uint32_t packetCount)
{
	uint32_t packet_index, inner_index;
	int sortNeeded = 0, tempLen = 0;
	uint8_t *srctempbuff;
	uint8_t *dsttempbuff;
	uint8_t *ivtempbuff;

	packet_index = packetCount;

	while(packet_index--) {

		/* check if all packets are sorted by decreasing length */
		if (packet_index > 0
			&& bufferLenInBytes[packet_index - 1] <
			   bufferLenInBytes[packet_index])
		{
			/* this packet array is not correctly sorted  */
			sortNeeded = 1;
		}
	}

	if (sortNeeded) {

		/* sort packets in decreasing buffer size from [0] to [n]th packet,
		** where buffer[0] will contain longest buffer and buffer[n] will
		contain the shortest buffer.
		4 arrays are swapped :
		- pointers to input buffers
		- pointers to output buffers
		- pointers to input IV's
		- input buffer lengths
		*/
		packet_index = packetCount;
		while(packet_index--) {

			inner_index = packet_index;
			while (inner_index--) {

				if (bufferLenInBytes[packet_index] > bufferLenInBytes[inner_index]) {

					/* swap buffers to arrange in descending order from [0]. */
					srctempbuff = pBufferIn[packet_index];
					dsttempbuff = pBufferOut[packet_index];
					ivtempbuff = IV[packet_index];
					tempLen = bufferLenInBytes[packet_index];

					pBufferIn[packet_index] = pBufferIn[inner_index];
					pBufferOut[packet_index] = pBufferOut[inner_index];
					IV[packet_index] = IV[inner_index];
					bufferLenInBytes[packet_index] = bufferLenInBytes[inner_index];

					pBufferIn[inner_index] = srctempbuff;
					pBufferOut[inner_index] = dsttempbuff;
					IV[inner_index] = ivtempbuff;
					bufferLenInBytes[inner_index] = tempLen;
				}
			} /* for inner packet index (inner bubble-sort) */
		} /* for outer packet index (outer bubble-sort) */
	 } /* if sortNeeded */

	packet_index = 0;
	/* process 4 buffers at-a-time */
	while (packetCount >= 4)
	{
		packetCount -= 4;
		sso_snow3g_f8_4_buffer(pCtx, IV[packet_index+0], IV[packet_index+1], IV[packet_index+2], IV[packet_index+3],
				pBufferIn[packet_index+0], pBufferOut[packet_index+0], bufferLenInBytes[packet_index+0],
					pBufferIn[packet_index+1], pBufferOut[packet_index+1], bufferLenInBytes[packet_index+1],
					pBufferIn[packet_index+2], pBufferOut[packet_index+2], bufferLenInBytes[packet_index+2],
					pBufferIn[packet_index+3], pBufferOut[packet_index+3], bufferLenInBytes[packet_index+3]);
		packet_index += 4;
	}
	/* process 2 packets at-a-time */
	while (packetCount >= 2)
	{
		packetCount -= 2;
		sso_snow3g_f8_2_buffer(pCtx, IV[packet_index+0], IV[packet_index+1],
	   				pBufferIn[packet_index+0], pBufferOut[packet_index+0], bufferLenInBytes[packet_index+0],
	   				pBufferIn[packet_index+1], pBufferOut[packet_index+1], bufferLenInBytes[packet_index+1]);
		packet_index+=2;
	}
	/* remaining packets are processed 1 at a time */
	while (packetCount--)
	{
		sso_snow3g_f8_1_buffer(pCtx, IV[packet_index+0], pBufferIn[packet_index+0], pBufferOut[packet_index+0], bufferLenInBytes[packet_index+0]);
		packet_index++;
	}


} /* sso_snow3g_f8_n_buffer() */

