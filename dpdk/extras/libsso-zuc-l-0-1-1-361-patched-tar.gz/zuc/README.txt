###############################################################################
#
# INTEL CONFIDENTIAL
# Copyright 2009-2013 Intel Corporation All Rights Reserved.
# 
# The source code contained or described herein and all documents related to the
# source code ("Material") are owned by Intel Corporation or its suppliers or
# licensors. Title to the Material remains with Intel Corporation or its
# suppliers and licensors. The Material may contain trade secrets and proprietary
# and confidential information of Intel Corporation and its suppliers and
# licensors, and is protected by worldwide copyright and trade secret laws and
# treaty provisions. No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or disclosed
# in any way without Intels prior express written permission.
# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be
# express and approved by Intel in writing.
# 
# Include any supplier copyright notices as supplier requires Intel to use.
# Include supplier trademarks or logos as supplier requires Intel to use,
# preceded by an asterisk.
# An asterisked footnote can be added as follows: 
#   *Third Party trademarks are the property of their respective owners.
# 
# Unless otherwise agreed by Intel in writing, you may not remove or alter this
# notice or any other notice embedded in Materials by Intel or Intels suppliers
# or licensors in any way.
# 
#  version: LIBSSO_ZUC.L.0.1.1-361
#
##############################################################################/


1	LIBSSO LIBRARY
-------------------
The Libsso library provides optimised versions of 3GPP confidentiality and 
integrity cryptographic algorithms 128-EEA3 and 128-EIA3. 

1.1	PACKAGE CONTENTS: 
---------------------
This package contains the source code ,build system and some benchmarks for
an optimised implementation of the ZUC cryptographic algorithms.
The benchmarks provided can be used to determine your systems performance and
as sample code describing how the libsso library can be used.


2	BUILD CONFIGURATION	
------------------------
The Libsso library can by optimally configured for several different Intel 
architectures. The libsso zuc library supports Intel� microarchitecture 
processors with Intel� AVX in 64 bit. The Makefile ensures this setting: 
    CC_FLAGS += -D_ZUC_AVX 

2.2	COMPILER CONFIGURATION: 	
---------------------------
The libsso build system supports both GNU GCC and Intel C++ Compilers. You can 
specify your compiler configuration from the top level Makefile. "libsso/Makefile"

When both compilers are available, ICC is used on files that are known to
benefit from ICC compilation.

Here are some examples of libsso compiler configurations.

CC 
-----------
CC = gcc
or
CC = icc

If using ICC don't forget to set your ICC flags for 64 bit.

Example:
#	source /opt/intel/system_studio_2013.0.016/bin/iccvars.sh intel64

3	THE LIBSSO LIBRARY:	
----------------------
The libsso library API describes the interface to the highly optimized functions
and their parameters. 

The libsso library API files are located at: 
"libsso/include/sso_zuc.h"

3.1	BUILDING AND USING THE LIBRARY: 
-----------------------------------
The libsso package comes with two benchmark and one unit application - one for static
library linkage, and one for dynamic.

Untar the libsso package, cd to the base directory and build using the default 
configuration. 
# cd libsso
# make 

During compilation two libraries are generated:
	- "libsso/build/libsso_zuc.a"
	- "libsso/build/libsso_zuc.so"

In case of shared library use, it's mandatory to inform future aplication where newly created
lib file is located. There are two options:
1. copy file to already define shared library path
2. modify LD_LIBRARY_PATH variable with new directory
 On Ubuntu it wil be export LD_LIBRARY_PATH=$(pwd)/libsso/build 

Building the libsso benchmarks
# cd libsso
# make bench  

After a successful build the benchmark executables will reside here:
"libsso/build/sso_zuc_bench"
"libsso/build/sso_zuc_bench_shared"

The libsso benchmark application takes no arguments.


4	SAMPLE SETUP:
----------------
Here is an example setup for a Intel� microarchitecture codename Haswell
architecture.

Change to base directory
# cd libsso/

Clean before re-building
# make  clean

Set compiler flag
CC = gcc
or
CC = icc

Build library
# make 

Build benchmark application
# make bench 

Run benchmark application
# libsso/build/sso_zuc_bench
or
# libsso/build/sso_zuc_bench_shared

Build unit test application
# make  unit

Run unit test application
# libsso/unit/sso_zuc_unit
or
# libsso/unit/sso_zuc_unit_shared

Output of benchmark using zuc alogorithm on SNB with ICC:
-----------------------------------------------------------------------------
Running Performance Tests

Libsso Zuc for 1 buffers @ 1995.17 Hz.
Bytes    Cy/Op           Cy/Byte         Mbps
40       3601.39         90.03           177.28
64       3567.56         55.74           286.34
80       4749.91         59.37           268.83
128      4730.71         36.96           431.87
240      7084.61         29.52           540.71
256      7061.87         27.59           578.61
400      10583.99        26.46           603.23
512      11725.53        22.90           696.96
600      14090.74        23.48           679.65
1024     21061.77        20.57           776.02
2048     39726.97        19.40           822.84


Libsso Zuc for 4 buffers @ 1995.17 Hz.
Bytes    Cy/Op           Cy/Byte         Mbps
40       13981.83        87.39           182.65
64       13671.56        53.40           298.88
80       19415.61        60.67           263.07
128      16265.76        31.77           502.42
240      24454.43        25.47           626.59
256      21383.17        20.88           764.36
400      32078.07        20.05           796.12
512      31622.59        15.44           1033.72
600      39629.08        16.51           966.64
1024     52104.79        12.72           1254.73
2048     93008.67        11.35           1405.84


Libsso Zuc for 8 buffers @ 1995.17 Hz.
Bytes    Cy/Op           Cy/Byte         Mbps
40       28084.59        87.76           181.87
64       27880.52        54.45           293.12
80       38713.95        60.49           263.86
128      32434.25        31.67           503.92
240      49013.06        25.53           625.26
256      42631.34        20.82           766.78
400      64217.27        20.07           795.37
512      62998.47        15.38           1037.77
600      79539.09        16.57           963.23
1024     103686.91       12.66           1261.06
2048     185135.52       11.30           1412.54

The benchmark application finished with exit code: 0


http://www.intel.com/performance/
http://www.intel.com/content/www/us/en/benchmarks/benchmark.html

6   MISCELLANEOUS
------------------



