/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

/*-----------------------------------------------------------------------
* Zuc benchmark
*-----------------------------------------------------------------------
*
* A simple performance benchmark test for ZUC
*
*-----------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "sso_zuc.h"
#include "sso_zuc_internal.h"
#include "sso_common.h"
#include "sso_utils.h"

#include "xmmintrin.h"

#define ITERATIONS 100000 /*(1024*100)*/

#define MAXBUFS 16
#define MAX_DATA_LEN 2048
#define ZUC_KEY_LEN_IN_BYTES 16
#define ZUC_IV_LEN_IN_BYTES 16

#define PASS_STATUS 0
#define FAIL_STATUS -1

/*keys for functional test cases*/
ALIGN64 uint8_t KEY1[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
ALIGN64 uint8_t KEY2[] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
                          0xff,0xff,0xff,0xff,0xff,0xff};
ALIGN64 uint8_t KEY3[] = {0x3d,0x4c,0x4b,0xe9,0x6a,0x82,0xfd,0xae,0xb5,0x8f,
                          0x64,0x1d,0xb1,0x7b,0x45,0x5b};
ALIGN64 uint8_t KEY4[] = {0x4d,0x32,0x0b,0xfa,0xd4,0xc2,0x85,0xbf,0xd6,0xb8,
                          0xbd,0x00,0xf3,0x9d,0x8b,0x41};

/*vectors for test set 3 and 4*/
ALIGN64 uint8_t IV1[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
ALIGN64 uint8_t IV2[] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,
                         0xff,0xff,0xff,0xff,0xff,0xff};
ALIGN64 uint8_t IV3[] = {0x84,0x31,0x9a,0xa8,0xde,0x69,0x15,0xca,0x1f,0x6b,
                         0xda,0x6b,0xfb,0xd8,0xc7,0x66};
ALIGN64 uint8_t IV4[] = {0x52,0x95,0x9d,0xab,0xa0,0xbf,0x17,0x6e,0xce,0x2d,
                         0xc3,0x15,0x04,0x9e,0xb5,0x74};

/*Result Sets*/
ALIGN64 uint32_t RS1[] = {0x27bede74,0x018082da};
ALIGN64 uint32_t RS2[] = {0x0657cfa0,0x7096398b};
ALIGN64 uint32_t RS3[] = {0x14f1c272,0x3279c419};
ALIGN64 uint32_t RS4[] = {0xed4400e7,0x0633e5c5};

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function returns the processor frequency.
 * ************************************************/
double get_processor_freq(void)
{
    struct timezone tzone;
    struct timeval tvstart, tvstop;
    uint64_t start, finish;
    uint64_t microsecs;
    memset(&tzone, 0, sizeof(tzone));
	
    gettimeofday(&tvstart, &tzone);
    start = sso_rdtsc();
    gettimeofday(&tvstart, &tzone);
    usleep(250000);
    gettimeofday(&tvstop, &tzone);
    finish = sso_rdtsc();
    gettimeofday(&tvstop, &tzone);
    microsecs = ((tvstop.tv_sec-tvstart.tv_sec)*1000000) + (tvstop.tv_usec-tvstart.tv_usec);
	
    return (double) (finish - start) / microsecs;
}

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function generates len bytes of random data.
 * 
 * pData = pointer to buffer where generated randon data will be stored
 * len = length of data to be generated
************************************************/
void genRandomData(uint8_t* pData, const uint32_t len)
{
    uint32_t n;

    if(pData != NULL)
    {
        srand(time(NULL));

        for(n = 0; n < len; n++)
        {
            pData[n] = (uint8_t)(rand() & 0xFF);
        }
    }
    else
    {
        printf("Warning: An invalid data buffer address!\n");
    }

}

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function allocates memory for buffers and set random data in each buffer
 *
 * pSrcData = pointers to the new source buffers
 * numOfBuffs = number of buffers
 * ************************************************/
uint32_t createSourceData(uint8_t *pSrcData[MAXBUFS], uint32_t numOfBuffs) 
{
    uint32_t i = 0, j = 0;
	
    for(i = 0;i < numOfBuffs;i++)
    {
        pSrcData[i] = (uint8_t*) _mm_malloc(MAX_DATA_LEN,64);

        if(!pSrcData[i])
        {
            printf("_mm_malloc(pSrcData[i]): failed!\n");
            
            for(j = 0;j < i;j++)
            {
                _mm_free(pSrcData[j]);
                pSrcData[j] = NULL;
            }
            
            return FAIL_STATUS;
        }
    }
           
    for(i=0;i < numOfBuffs;i++)
    {            
        genRandomData(pSrcData[i], MAX_DATA_LEN);
    }
    
    return PASS_STATUS;
}

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function creates source data and vector buffers.
 *
 * keyLen = key length
 * pKeys = array of pointers to the new key buffers
 * ivLen = vector length
 * pIV = array of pointers to the new vector buffers
 * numOfBuffs = number of buffers
************************************************/
uint32_t createKeyVecData(uint32_t keyLen, uint8_t *pKeys[MAXBUFS], 
                          uint32_t ivLen, uint8_t *pIV[MAXBUFS], 
                          uint32_t numOfBuffs) 
{
    uint32_t i = 0, j = 0;
	
    for(i = 0;i < numOfBuffs;i++)
    {
        pIV[i] = (uint8_t *)_mm_malloc(ivLen, 64);
        
        if(!pIV[i]) 
        {
            printf("_mm_malloc(pIV[i]): failed!\n");

            for(j = 0;j < i;j++)
            {
                _mm_free(pIV[j]);
                _mm_free(pKeys[j]);
            }            

            return FAIL_STATUS;
        }

        pKeys[i] = _mm_malloc(keyLen, 64);
       
        if(!pKeys[i]) 
        {
            printf("_mm_malloc(pKeys[i]): failed!\n");

            for(j = 0;j <= i;j++)
            {
                _mm_free(pIV[j]);

                if(j < i)
                {               
                    _mm_free(pKeys[j]);
                }
            }
            return FAIL_STATUS;
        }
    }
	
    for(i=0; i < numOfBuffs; i++)
    {
        genRandomData(pKeys[i], keyLen);
        genRandomData(pIV[i], ivLen);            
    }
    
    return PASS_STATUS;
}

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function free memory pointed to by an array of pointers
 *
 * arr = array of memory pointers
 * length = length of pointer array (or number of pointers whose buffers 
 * should be freed)
 * ************************************************/
void freePtrArray(uint8_t *pArr[MAXBUFS], uint32_t arrayLength)
{
    uint32_t i = 0;

    for(i = 0;i < arrayLength;i++)
    {
        _mm_free(pArr[i]);
    }
}

int main(int argc, char ** argv)
{
    uint32_t numBuffs=1, numPktSizes=0, i=0 , j=0,a = 0;
    uint32_t status = PASS_STATUS;
    uint8_t *pKeys[MAXBUFS];
    uint8_t* pIV[MAXBUFS];
    
    uint8_t* pSrcData[MAXBUFS];
    uint32_t packetLen[MAXBUFS];
    uint64_t  cpu_cycles=0, start=0, stop=0;

    /*Packet sizes to use in testing.*/
    uint32_t packetSizes[] = {40, 64, 80, 128, 240, 256, 400, 512, 600, 1024,
                              2048};
    numPktSizes=sizeof(packetSizes)/sizeof(uint32_t);
    unsigned long long cycleCount[numPktSizes];
    double Mbps=0;
    double cpufreq = get_processor_freq();
	double cycles = 0;  

    /*Check CPU capabilities*/	
    if(sso_zuc_cpuid_check())
    {            
        printf("sso_zuc_cpuid_check(): Failed \n"); 
        return FAIL_STATUS;
    }   

    printf("Running Performance Tests\n");
    fflush(stdout);

    for(a = 0;a < 3;a++)
    {
        switch(a)
        {
            case 0: numBuffs = 1;break;
            case 1: numBuffs = 4;break;
            default: numBuffs = 8;break;
        }

        /*Create test data buffers + populate with random data*/
        if(createSourceData(pSrcData, numBuffs))
        {
            printf("createSourceData() error \n");   
            return FAIL_STATUS;
        }

        /*Create random keys and vectors*/    
        if(createKeyVecData(ZUC_KEY_LEN_IN_BYTES, pKeys, ZUC_IV_LEN_IN_BYTES, 
                            pIV, numBuffs))
        {
            printf("createKeyVecData() error \n");
            for(i=0; i < numBuffs; i++)/*MAXBUFS*/
            {           
                _mm_free(pSrcData[i]);
            }    
            return FAIL_STATUS;
        }      
        
        /*Calculate the length of time it takes to get cpuid */
        cpu_cycles = get_cpuid_cycles();

        if(numBuffs == 1) 
        {        

            /* An initial run to warm up the cache */
            sso_zuc_eea3_1_buffer(pKeys[0], pIV[0], pSrcData[0], pSrcData[0],
                             packetSizes[0]);

            for(i = 0;i < numPktSizes; i++) 
            {
                cycleCount[i] = 0;
                 
                start = sso_rdtscp();
                
                for(j=0; j < ITERATIONS; j++)
                {
                    sso_zuc_eea3_1_buffer(pKeys[0], pIV[0], pSrcData[0], pSrcData[0],
                                     packetSizes[i]);
                }

                stop = sso_rdtscp();
                cycleCount[i] +=  (stop - start) - cpu_cycles;
            }
        } 
        else if(numBuffs == 4)
        {          
            for(i=0;i < numPktSizes; i++)
            {                
                cycleCount[i] = 0;
         
                for(j = 0; j < numBuffs; j++)
                {
                    packetLen[j] = packetSizes[i];
                }

                sso_zuc_eea3_4_buffer(pKeys, pIV, pSrcData, pSrcData, packetLen);

                start = sso_rdtscp();

                for(j=0; j < ITERATIONS; j++)
                {
                    sso_zuc_eea3_4_buffer(pKeys, pIV, pSrcData, pSrcData,
                                     packetLen);
                }

                stop = sso_rdtscp();
                cycleCount[i] +=  (stop - start) - cpu_cycles;
            }
        }
        else 
        {
            for(i=0;i < numPktSizes;i++)
            {
                cycleCount[i] = 0;
                
                for(j = 0; j < numBuffs; j++)
                {
                    packetLen[j] = packetSizes[i];
                }
                /* An initial run to warm up the cache */
                sso_zuc_eea3_n_buffer(pKeys, pIV, pSrcData, pSrcData, packetLen,
                                 numBuffs);

                start = sso_rdtscp();
                for(j=0; j < ITERATIONS; j++) 
                {
                    sso_zuc_eea3_n_buffer(pKeys, pIV, pSrcData, pSrcData,
                                     packetLen, numBuffs);
                }

                stop = sso_rdtscp();
                cycleCount[i] +=  (stop - start) - cpu_cycles;
            }
        }

        printf("\nLibsso Zuc for %d buffers @ %0.2f Hz. \n", numBuffs, cpufreq);
        printf("%s\t %s\t\t %s\t %s\t\n", "Bytes", "Cy/Op", "Cy/Byte", "Mbps");

        for(i = 0;i < numPktSizes;i++) 
        {
            cycles =  (double) cycleCount[i]/ (ITERATIONS * 1.0);
            printf("%d", packetSizes[i]);			/*Packet size*/
            printf("\t %4.2f", cycles);		        /*Cycles per op*/
            cycles /= (packetSizes[i] * numBuffs);
            printf("\t %4.2f", cycles);		        /*Cycles per byte*/
            Mbps = (cpufreq/cycles);
            Mbps *= 8;
            printf("\t\t %4.2f", Mbps);			    /*Mbps*/
            printf("\n");
        }
        printf("\n");

        freePtrArray(pKeys, numBuffs);/*Free the key buffers*/
        freePtrArray(pIV, numBuffs);/*Free the vector buffers*/
        freePtrArray(pSrcData, numBuffs);/*Free the source buffers*/
    }  

    printf("The benchmark application finished with exit code: %d\n", status);

    return status;
}
