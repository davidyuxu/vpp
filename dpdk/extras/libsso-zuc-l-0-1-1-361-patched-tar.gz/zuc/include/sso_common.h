/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

#ifndef _SSO_COMMON_H_
#define _SSO_COMMON_H_

#include <emmintrin.h>
#include <string.h>
#include <stdint.h>

#define NUM_PACKETS_1 1
#define NUM_PACKETS_2 2
#define NUM_PACKETS_3 3
#define NUM_PACKETS_4 4
#define NUM_PACKETS_8 8
#define NUM_PACKETS_16 16

typedef union _m128_u
{
    uint8_t     byte[16];
    uint16_t    word[8];
    uint32_t    dword[4];
    uint64_t    qword[2];
    __m128i     m;
} m128_t;

typedef union _m64_u
{
    uint8_t     byte[8];
    uint16_t    word[4];
    uint32_t    dword[2];
    __m64       m;
} m64_t;


/*************************************************************************
* @description - this function is used to copy the right number of bytes 
*                from the source to destination buffer
*
* @param pSrc [IN] - pointer to an input Byte array (at least len bytes available)
* @param pDst [IN] - pointer to the output buffer (at least len bytes available)
* @param len  [IN] - length in bytes to copy (0 to 4)
*
*************************************************************************/
static inline void sso_memcpy_keystream_32(uint8_t *pDst, uint8_t *pSrc, uint32_t len)
{
    switch(len)
    {
    case 4 : *(uint32_t *)pDst = *(uint32_t *)pSrc;
        break;
    case 3 : pDst[2] = pSrc[2];
    case 2 : pDst[1] = pSrc[1];
    case 1 : pDst[0] = pSrc[0];
    }
}

/*************************************************************************
* @description - this function is used to XOR the right number of bytes 
*                from a keystrea and a source into a destination buffer
*
* @param pSrc [IN] - pointer to an input Byte array (at least 4 bytes available)
* @param pDst [IN] - pointer to the output buffer (at least 4 bytes available)
* @param KS  [IN]  - 4 bytes of keystream number, must be reversed
*                    into network byte order before XOR
*
*************************************************************************/
static inline void sso_xor_keystream_reverse_32(uint8_t *pDst, uint8_t *pSrc, uint32_t KS)
{
#if (defined(SNOW3G_C))
    pDst[0] = pSrc[0] ^ ((KS >> 24) & 0xff);
    pDst[1] = pSrc[1] ^ ((KS >> 16) & 0xff);
    pDst[2] = pSrc[2] ^ ((KS >> 8)  & 0xff);
    pDst[3] = pSrc[3] ^ (KS & 0xff);
#else
    uint32_t *pSrc32 = (uint32_t *)pSrc;
    uint32_t *pDst32 = (uint32_t *)pDst;
    *pDst32 = *pSrc32 ^ __builtin_bswap32(KS);
#endif
}

/******************************************************************************
 * @description - this function is used to do a keystream operation
 * @param pSrc [IN] - pointer to an input Byte array (at least 8 bytes available)
 * @param pDst [IN] - pointer to the output buffer (at least 8 bytes available)
 * @param keyStream [IN] -  the Keystream value (8 bytes)
 ******************************************************************************/
static inline uint8_t *sso_xor_keystrm_rev(uint8_t *pDst, uint8_t *pSrc, uint64_t keyStream)
{
    /* default: XOR ONLY, read the input buffer, update the output buffer */
    uint64_t *pSrc64 = (uint64_t *)pSrc;
    uint64_t *pDst64 = (uint64_t *)pDst;
    *pDst64 = *pSrc64++ ^ __builtin_bswap64(keyStream);
    return (uint8_t *)pSrc64;
}

/******************************************************************************
 * @description - this function is used to copy the right number of bytes 
 *                from the source to destination buffer
 * @param pSrc [IN] - pointer to an input Byte array (at least len bytes available)
 * @param pDst [IN] - pointer to the output buffer (at least len bytes available)
 * @param len  [IN] - length in bytes to copy
 ******************************************************************************/
static inline void sso_memcpy_keystrm(uint8_t *pDst, uint8_t *pSrc, uint32_t len)
{
   switch(len)
   {
     case 8 : *(uint64_t *)pDst = *(uint64_t *)pSrc;
              break;
     case 7 : pDst[6] = pSrc[6];
     case 6 : pDst[5] = pSrc[5];
     case 5 : pDst[4] = pSrc[4];
     case 4 : *(uint32_t *)pDst = *(uint32_t *)pSrc;
              break;
     case 3 : pDst[2] = pSrc[2];
     case 2 : pDst[1] = pSrc[1];
     case 1 : pDst[0] = pSrc[0];
   }
}


#endif /* _SSO_COMMON_H_ */

