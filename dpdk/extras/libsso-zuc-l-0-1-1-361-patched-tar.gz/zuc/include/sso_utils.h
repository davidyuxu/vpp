/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

#ifndef _SSO_UTILS_H_
#define _SSO_UTILS_H_

#include <emmintrin.h>
#include <sys/time.h>
#include <stdint.h>
#include <time.h>
#include <stdio.h>


typedef unsigned long long ticks_t;

/* cpuid for intel e gnu compiler */
#if defined (__INTEL_COMPILER)
#define __CPUID(a, b)\
    __cpuid((a), (b))
#else /* #if defined (__INTEL_COMPILER) */
#define __CPUID(in,a,b,c,d)\
   asm volatile ("cpuid": "=a" (a), "=b" (b), "=c" (c), "=d" (d) : "a" (in));
#endif /* #if defined (__INTEL_COMPILER) */

static void __inline__ cpuid(void)
{
#if defined (__INTEL_COMPILER)
    int CPUInfo[4] = {-1};
    __CPUID(CPUInfo, 1);
#else /* #if defined (__INTEL_COMPILER) */
    unsigned int a = 0x00, b = 0x00, c= 0x00, d = 0x00;
    __CPUID(0x00, a, b, c, d);
#endif /* #if defined (__INTEL_COMPILER) */    
}

static inline ticks_t sso_rdtsc(void)
{
    unsigned long a, d;
    
    asm volatile ("rdtsc" : "=a" (a), "=d" (d));
    return (((ticks_t)a) | (((ticks_t)d) << 32));
}

/* 
    Serialized version of the rdtsc instruction
    to properly count cycles need to remove the cpuid overhead
    
    ticks_t cpuid_cycles = get_cpuid_cycles();
    ticks_t s1 = rdtscp();
    {
        code_to_benchmark();
    }
    ticks_t s2 = rdtscp();
    ticks_t measured_time = s2 - s1 - cpuid_cycles; 
*/
static inline ticks_t sso_rdtscp(void)
{
    volatile unsigned long a = 0, d = 0;
    ticks_t returnval = 0;
    
    cpuid();
    asm volatile ("rdtsc" : "=a" (a), "=d" (d));
    returnval = (((ticks_t)d) << 32);
    returnval |= ((ticks_t)a);

    return returnval;
}


/*
    This function extimate the number of clock 
    cycles for the cpuid instruction
    Needs to run the be run at least 3 times to "warm-up"
    and report a stable number
*/
static inline ticks_t get_cpuid_cycles()
{
    volatile ticks_t cpuid_cycles  = 0;     
    volatile ticks_t s1;
    
    cpuid();
    s1 = sso_rdtsc();
    cpuid();
    cpuid_cycles = sso_rdtsc();
    cpuid_cycles -= s1;
    //printf("cpuid_cycles: %llu \n", cpuid_cycles);
    
    cpuid();
    s1 = sso_rdtsc();
    cpuid();
    cpuid_cycles = sso_rdtsc();
    cpuid_cycles -= s1;
    //printf("cpuid_cycles: %llu \n", cpuid_cycles);
    
    cpuid();
    s1 = sso_rdtsc();
    cpuid();
    cpuid_cycles = sso_rdtsc();
    cpuid_cycles -= s1;
    //printf("cpuid_cycles: %llu \n", cpuid_cycles);
    
    return cpuid_cycles;    
}

#endif /* _SSO_UTILS_H_ */
