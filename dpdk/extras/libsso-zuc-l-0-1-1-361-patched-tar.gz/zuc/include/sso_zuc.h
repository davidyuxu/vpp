/******************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
******************************************************************************/

/**
 ******************************************************************************
 * @file sso_zuc.h
 *
 * @defgroup sso_zuc ZUC API
 *
 * @description
 *      This header file defines the API definition of the ZUC algorithm. The
 *      ZUC algorithm is the core of the standardised 3GPP Confidentiality and
 *      Integrity algorithms 128-EEA3 and 128-EIA3.
 *
 *      The API's defined here are used to apply the ZUC algorithm to an input
 *      buffer or buffer's.
 *
 *****************************************************************************/

#ifndef SSO_ZUC_H_
#define SSO_ZUC_H_


#ifdef __cplusplus
extern "C" {
#endif


#include <stdlib.h>
#include <stdint.h>







/**
 *****************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      This API will perform 128-EEA3 on a single input packet. This can be
 *      use to either encrypt or decrypt a packet.
 *
 * @param[in]       pKey                Pointer to the 128-bit Cipher KEY to
 *                                      use. For performance reasons it is
 *                                      expected this buffer be aligned on a
 *                                      64-byte boundary.
 *
 * @param[in]       pIv                 Pointer to the 128-bit Initialization
 *                                      Vector, IV to use. For performance
 *                                      reasons it is expected this buffer be
 *                                      aligned on a 64-byte boundary.
 *
 * @param[in]       pBufferIn           Pointer to the Input buffer. For
 *                                      performance reasons it is expected this
 *                                      buffer be aligned on a 64-byte boundary.
 *
 * @param[in,out]   pBufferOut          Pointer to the Output buffer. For
 *                                      performance reasons it is expected this
 *                                      buffer be aligned on a 64-byte boundary.
 *
 * @param[in]       lengthInBytes       The size of the input and output
 *                                      buffer in number of bytes.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
__attribute__((gnu_inline)) extern inline void sso_zuc_eea3_1_buffer(uint8_t *pKey,
                             uint8_t *pIv,
                             uint8_t *pBufferIn,
                             uint8_t *pBufferOut,
                             uint32_t lengthInBytes);

/**
 *****************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      This API will perform 128-EEA3 on a four input packets. This can be
 *      use to either encrypt or decrypt a packet.
 *
 * @param[in]       pKey                Pointer an array containing address's
 *                                      of the four 128-bit Cipher KEYs to
 *                                      use. For performance reasons it is
 *                                      expected that each 128-bit KEY buffer
 *                                      be aligned on a 64-byte boundary.
 *
 * @param[in]       pIv                 Pointer an array containing address's
 *                                      of the four 128-bit IV's to
 *                                      use. For performance reasons it is
 *                                      expected that each 128-bit KEY buffer
 *                                      be aligned on a 64-byte boundary.
 *
 * @param[in]       pBufferIn           Pointer an array containing address's
 *                                      of the four Input buffers. For
 *                                      performance reasons it is expected that
 *                                      each buffer be aligned on a 64-byte
 *                                      boundary.
 *
 * @param[in,out]   pBufferOut          Pointer an array containing address's
 *                                      of the four Input buffers. For
 *                                      performance reasons it is expected that
 *                                      each buffer be aligned on a 64-byte
 *                                      boundary.
 *
 * @param[in]       lengthInBytes       Array of four integers each containing
 *                                      the size of the four input buffers.
 *                                      Element 0 in the array contains the
 *                                      length of input buffer 1, element 1
 *                                      contains the length of input buffer 2
 *                                      and so on.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
__attribute__((gnu_inline)) extern inline void sso_zuc_eea3_4_buffer(uint8_t *pKey[4], uint8_t *pIv[4],
                      uint8_t *pBufferIn[4], uint8_t *pBufferOut[4],
                      uint32_t lengthInBytes[4]);


/**
 *****************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      This API will perform 128-EEA3 on N input packets. This can be
 *      use to either encrypt or decrypt a packet.
 *
 * @param[in]       pKey                Pointer an array containing address's
 *                                      of the N 128-bit Cipher KEYs to
 *                                      use. For performance reasons it is
 *                                      expected that each 128-bit KEY buffer
 *                                      be aligned on a 64-byte boundary.
 *
 * @param[in]       pIv                 Pointer an array containing address's
 *                                      of the N 128-bit IV's to
 *                                      use. For performance reasons it is
 *                                      expected that each 128-bit KEY buffer
 *                                      be aligned on a 64-byte boundary.
 *
 * @param[in]       pBufferIn           Pointer an array containing address's
 *                                      of the N Input buffers. For
 *                                      performance reasons it is expected that
 *                                      each buffer be aligned on a 64-byte
 *                                      boundary.
 *
 * @param[in,out]   pBufferOut          Pointer an array containing address's
 *                                      of the N Input buffers. For
 *                                      performance reasons it is expected that
 *                                      each buffer be aligned on a 64-byte
 *                                      boundary.
 *
 * @param[in]       lengthInBytes       Array of four integers each containing
 *                                      the size of the N input buffers.
 *                                      Element 0 in the array contains the
 *                                      length of input buffer 1, element 1
 *                                      contains the length of input buffer 2
 *                                      and so on.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
__attribute__((gnu_inline)) extern inline void sso_zuc_eea3_n_buffer(uint8_t *pKey[], uint8_t *pIv[],
                      uint8_t *pBufferIn[], uint8_t *pBufferOut[],
                      uint32_t lengthInBytes[], uint32_t numBuffers);


/**
 *****************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      This API will perform 128-EIA3 on a single input packet. Based on the
 *      input the API will compute a 32-bit message authentication code MAC-I.
 *
 * @param[in]       pKey                Pointer to the 128-bit Cipher KEY to
 *                                      use. For performance reasons it is
 *                                      expected this buffer be aligned on a
 *                                      64-byte boundary.
 *
 * @param[in]       pIv                 Pointer to the 128-bit Initialization
 *                                      Vector, IV to use. For performance
 *                                      reasons it is expected this buffer be
 *                                      aligned on a 64-byte boundary.
 *
 * @param[in]       pBufferIn           Pointer to the Input buffer. For
 *                                      performance reasons it is expected this
 *                                      buffer be aligned on a 64-byte boundary.
 *
 * @param[in]       lengthInBits        The size of the input buffer in number
 *                                      of bits.
 *
 * @param[in,out]   pMacI               Pointer to a 32-bit memory location
 *                                      that will contain the computed MAC-I
 *                                      upon successful completion of the API.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
__attribute__((gnu_inline)) extern inline void sso_zuc_eia3_1_buffer(uint8_t *pKey,
                                  uint8_t *pIv,
                                  uint8_t *pBufferIn,
                                  uint32_t lengthInBits,
                                  uint32_t *pMacI);


/**
 *****************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      This API is used to check the CPU capabilities required for this
 *      implementation of the ZUC API.
 *
 *@retval 0 if specified CPU capabilities are available
 *@retval 1 if specified CPU capabilities are not available
 *
 *****************************************************************************/
uint32_t sso_zuc_cpuid_check(void);


#ifdef __cplusplus
} /* close the extern "C" { */
#endif

#endif /* SSO_ZUC_H_ */
