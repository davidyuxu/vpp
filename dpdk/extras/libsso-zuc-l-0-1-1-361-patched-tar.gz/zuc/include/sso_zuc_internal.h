/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

/**
 ******************************************************************************
 * @file sso_zuc_internal.h
 *
 * @ingroup sso_zuc
 *
 * @description
 *      This header file defines the internal API's and data types for the
 *      3GPP algorithm ZUC.
 *
 *****************************************************************************/

#ifndef ZUC_INTERNAL_H_
#define ZUC_INTERNAL_H_


#include <stdio.h>
#include "win64lin64.h"
#include "immintrin.h"


/* 64 bytes of Keystream will be generated */
#define ZUC_KEYSTREAM_LENGTH_PER_ITERATION  (64)
#define NUM_LFSR_STATES                     (16)
#define ZUC_WORD                            (32)




#ifdef DEBUG
#define DEBUG_PRINT(fmt, args...) \
printf("%s:%d " fmt , __FUNCTION__,__LINE__, ## args)
#else
#define DEBUG_PRINT(fmt, args...)
#endif



/**
 ******************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      Macro will loop through keystream of lenght 64bytes and xor with the
 *      input buffer placing the result in the output buffer.
 *      KeyStream bytes must be swaped on 32bit boundary before this operation 
 *
 *****************************************************************************/
#define SSO_ZUC_XOR_KEYSTREAM(pIn64, pOut64, pKeyStream64)					\
{																			\
	int i =0;																\
	union SwapBytes_t {														\
		uint64_t l64;														\
		uint32_t w32[2];													\
	}swapBytes;																\
	/* loop through the key stream and xor 64 bits at a time */				\
	for(i =0; i < ZUC_KEYSTREAM_LENGTH_PER_ITERATION/8; i++)				\
	{																		\
		swapBytes.l64 = *pKeyStream64++;									\
		swapBytes.w32[0] = __builtin_bswap32(swapBytes.w32[0]);				\
		swapBytes.w32[1] = __builtin_bswap32(swapBytes.w32[1]);				\
		*pOut64++ = *pIn64++ ^ swapBytes.l64;								\
	}																		\
}

/**
 *****************************************************************************
 * @ingroup sso_zuc
 * @description
 *      Packed structure to store the ZUC state for a single packet. *
 *****************************************************************************/
typedef struct sso_zuc_state_s
{
    uint32_t lfsrState[16];
    /**< State registers of the LFSR */
    uint32_t fR1;
    /**< register of F */
    uint32_t fR2;
    /**< register of F */
    uint32_t bX0;
    /**< Output X0 of the bit reorganization */
    uint32_t bX1;
    /**< Output X1 of the bit reorganization */
    uint32_t bX2;
    /**< Output X2 of the bit reorganization */
    uint32_t bX3;
    /**< Output X3 of the bit reorganization */
} __attribute__((packed)) ssoZucState_t;

/**
 *****************************************************************************
 * @ingroup sso_zuc
 * @description
 *      Packed structure to store the ZUC state for a single packet. *
 *****************************************************************************/
typedef struct sso_zuc_state_4_s
{
    uint32_t lfsrState[16][4];
    /**< State registers of the LFSR */
    uint32_t fR1[4];
    /**< register of F */
    uint32_t fR2[4];
    /**< register of F */
    uint32_t bX0[4];
    /**< Output X0 of the bit reorganization for 4 packets */
    uint32_t bX1[4];
    /**< Output X1 of the bit reorganization for 4 packets */
    uint32_t bX2[4];
    /**< Output X2 of the bit reorganization for 4 packets */
    uint32_t bX3[4];
    /**< Output X3 of the bit reorganization for 4 packets */
} __attribute__((packed)) ssoZucState4_t;

/**
 *****************************************************************************
 * @ingroup sso_zuc
 * @description
 *      Structure to store pointers to the 4 keys to be used as input to
 *      @ref asm_ZucInitialization_4 and @ref asm_ZucGenKeystream64B_4
 *****************************************************************************/
typedef struct sso_zuc_key_4_s
{
    uint8_t *pKey1;
    /**< Pointer to 128-bit key for packet 1 */
    uint8_t *pKey2;
    /**< Pointer to 128-bit key for packet 2 */
    uint8_t *pKey3;
    /**< Pointer to 128-bit key for packet 3 */
    uint8_t *pKey4;
    /**< Pointer to 128-bit key for packet 4 */
}sso_ZucKey4_t;

/**
 *****************************************************************************
 * @ingroup sso_zuc
 * @description
 *      Structure to store pointers to the 4 IV's to be used as input to
 *      @ref asm_ZucInitialization_4 and @ref asm_ZucGenKeystream64B_4
 *****************************************************************************/
typedef struct sso_zuc_iv_4_s
{
    uint8_t *pIv1;
    /**< Pointer to 128-bit initialization vector for packet 1 */
    uint8_t *pIv2;
    /**< Pointer to 128-bit initialization vector for packet 2 */
    uint8_t *pIv3;
    /**< Pointer to 128-bit initialization vector for packet 3 */
    uint8_t *pIv4;
    /**< Pointer to 128-bit initialization vector for packet 4 */
}ssoZucIv4_t;





/**
 ******************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      Definition of the external function that implements the initialization
 *      stage of the ZUC algorithm. The function will initialize the state
 *      for a single packet operation.
 *
 * @param[in] pKey                  Pointer to the 128-bit initial key that
 *                                  will be used when initializing the ZUC
 *                                  state.
 * @param[in] pIv                   Pointer to the 128-bit initial vector that
 *                                  will be used when initializing the ZUC
 *                                  state.
 * @param[in,out] pState            Pointer to a ZUC state structure of type
 *                                  @ref ssoZucState_t that will be populated
 *                                  with the initialized ZUC state.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
extern void asm_ZucInitialization(uint8_t* pKey,
                                  uint8_t* pIv,
                                  ssoZucState_t * pState);

/**
 ******************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      Definition of the external function that implements the initialization
 *      stage of the ZUC algorithm for 4 packets. The function will initialize
 *      the state for 4 individual packets.
 *
 * @param[in] pKey                  Pointer to an array of 128-bit initial keys
 *                                  that will be used when initializing the ZUC
 *                                  state.
 * @param[in] pIv                   Pointer to an array of 128-bit initial
 *                                  vectors that will be used when initializing
 *                                  the ZUC state.
 * @param[in,out] pState            Pointer to a ZUC state structure of type
 *                                  @ref ssoZucState4_t that will be populated
 *                                  with the initialized ZUC state.
 *
 * @pre
 *      None
 *
 *****************************************************************************/
extern void asm_ZucInitialization_4(sso_ZucKey4_t *pKeys,
                                           ssoZucIv4_t *pIvs,
                                           ssoZucState4_t *pState);

/**
 ******************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      Definition of the external function that implements the working
 *      stage of the ZUC algorithm. The function will generate 64 bytes of
 *      keystream.
 *
 * @param[in,out] pKeystream        Pointer to an input buffer that will
 *                                  contain the generated keystream.

 * @param[in] pState                Pointer to a ZUC state structure of type
 *                                  @ref ssoZucState_t
 *
 * @pre
 *      A successful call to @ref asm_ZucInitialization to initialize the ZUC
 *      state.
 *
 *****************************************************************************/
extern void asm_ZucGenKeystream64B(uint32_t *pKeystream,
                                          ssoZucState_t * pState);

/**
 ******************************************************************************
 * @ingroup sso_zuc
 *
 * @description
 *      Definition of the external function that implements the working
 *      stage of the ZUC algorithm. The function will generate 64 bytes of
 *      keystream for four packets in parallel.
 *
 * @param[in] pState                Pointer to a ZUC state structure of type
 *                                  @ref ssoZucState4_t
 *
 * @param[in,out] pKeyStr1          Pointer to an input buffer that will
 *                                  contain the generated keystream for packet
 *                                  one.
 * @param[in,out] pKeyStr2          Pointer to an input buffer that will
 *                                  contain the generated keystream for packet
 *                                  two.
 * @param[in,out] pKeyStr3          Pointer to an input buffer that will
 *                                  contain the generated keystream for packet
 *                                  three.
 * @param[in,out] pKeyStr4          Pointer to an input buffer that will
 *                                  contain the generated keystream for packet
 *                                  four.
 *
 * @pre
 *      A successful call to @ref asm_ZucInitialization_4 to initialize the ZUC
 *      state.
 *
 *****************************************************************************/
extern void asm_ZucGenKeystream64B_4(ssoZucState4_t *pState,
                                     uint32_t* pKeyStr1, uint32_t* pKeyStr2,
                                     uint32_t* pKeyStr3, uint32_t* pKeyStr4);


void sso_print_zuc_state(ssoZucState_t *pState);

void sso_print_zuc_state4(ssoZucState4_t *pState);

/* the s-boxes */
extern const uint8_t S0[256];
extern const uint8_t S1[256];




#endif /* ZUC_INTERNAL_H_ */

