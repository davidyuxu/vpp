/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

/*-----------------------------------------------------------------------
* sso_zuc.c
*-----------------------------------------------------------------------
* An implementation of ZUC, the core algorithm for the
* 3GPP Confidentiality and Integrity algorithms.
*
*-----------------------------------------------------------------------*/

#include "sso_zuc.h"
#include "sso_zuc_internal.h"
#include "sso_common.h"





__attribute__((gnu_inline)) inline void sso_zuc_eea3_1_buffer(uint8_t *pKey,
                            uint8_t *pIv,
                            uint8_t *pBufferIn,
                            uint8_t *pBufferOut,
                            uint32_t lengthInBytes)
{
    ALIGN64 ssoZucState_t zucState;
    ALIGN64 uint8_t keyStream[64]; /* buffer to store 64 bytes of keystream */
#ifdef DEBUG
    uint32_t *pTemp = (uint32_t *) keyStream;
#endif
    ALIGN64 uint8_t tempSrc[64];
	ALIGN64 uint8_t tempDst[64];


    uint64_t *pIn64 = NULL, *pOut64 = NULL, *pKeyStream64 = NULL, *pTemp64 = NULL, *pdstTemp64 = NULL;

    uint32_t numKeyStreamsPerPacket = lengthInBytes/ ZUC_KEYSTREAM_LENGTH_PER_ITERATION;
    uint32_t numBytesLeftOver = lengthInBytes % ZUC_KEYSTREAM_LENGTH_PER_ITERATION;

    DEBUG_PRINT("Input buffer size:            %d\n", lengthInBytes);
    DEBUG_PRINT("Number of 64-byte KeyStreams: %d\n", numKeyStreamsPerPacket);
    DEBUG_PRINT("Remaining bytes in i/p:       %d\n", numBytesLeftOver);

    /* need to set the LFSR state to zero */
    memset(&zucState, 0, sizeof(ssoZucState_t));

    /* initialize the zuc state */
    asm_ZucInitialization(pKey, pIv, &(zucState));

    /* Loop Over all the Quad-Words in input buffer and XOR with the 64bits of
     * generated keystream */
    pOut64 = (uint64_t *) pBufferOut;
    pIn64 = (uint64_t *) pBufferIn;

    while(numKeyStreamsPerPacket--)
    {
        /* Generate the key stream 64 bytes at a time */
        asm_ZucGenKeystream64B((uint32_t *) &keyStream[0], &zucState);
#ifdef DEBUG
    pTemp = (uint32_t *) &keyStream[0];
    DEBUG_PRINT("Key-Stream: ");
    DEBUG_PRINT(" 0x%8x 0x%8x \n", pTemp[0], pTemp[1]);
#endif

        /* XOR The Keystream generated with the input buffer here */
        pKeyStream64 = (uint64_t *) keyStream;
        SSO_ZUC_XOR_KEYSTREAM(pIn64, pOut64, pKeyStream64);



   }


    /* Check for remaining 0 to 7 bytes */
    if(numBytesLeftOver)
    {
       asm_ZucGenKeystream64B((uint32_t *) &keyStream[0], &zucState);


       /* copy the remaining bytes into temporary buffer and XOR with the
        * 64-bytes of keystream. Then copy on the valid bytes back to the
        * output buffer */

       memcpy(&tempSrc[0], &pBufferIn[lengthInBytes - numBytesLeftOver],numBytesLeftOver);
       pKeyStream64 = (uint64_t *) &keyStream[0];
       pTemp64 = (uint64_t *) &tempSrc[0];
		pdstTemp64 = (uint64_t *) &tempDst[0];

       SSO_ZUC_XOR_KEYSTREAM(pTemp64, pdstTemp64 ,pKeyStream64);
       memcpy(&pBufferOut[lengthInBytes - numBytesLeftOver], &tempDst[0], numBytesLeftOver);


    }

}/*end sso_zuc_1_buffer*/









__attribute__((gnu_inline)) inline void sso_zuc_eea3_4_buffer(uint8_t *pKey[4], uint8_t *pIv[4],
                      uint8_t *pBufferIn[4], uint8_t *pBufferOut[4],
                      uint32_t lengthInBytes[4])
{

#if (defined(__AVX__))
	ALIGN64 ssoZucState4_t state;
#else
	ALIGN64 ssoZucState_t state[4];
#endif
    ALIGN64 ssoZucState_t singlePacketState;
    int i =0;
    /* Calculate the minimum input packet size */
    uint32_t bytes1 = (lengthInBytes[0] < lengthInBytes[1] ?
            lengthInBytes[0] : lengthInBytes[1]);
    uint32_t bytes2 = (lengthInBytes[2] < lengthInBytes[3] ?
            lengthInBytes[2] : lengthInBytes[3]);
    /* min number of bytes */
    uint32_t bytes = (bytes1 < bytes2) ? bytes1 : bytes2;
    uint32_t numKeyStreamsPerPacket = bytes/ZUC_KEYSTREAM_LENGTH_PER_ITERATION;
    uint32_t leftOverBytesInPacket[4] = {0};
    ALIGN64 uint8_t keyStr1[64], keyStr2[64], keyStr3[64], keyStr4[64];
    ALIGN64 uint8_t tempSrc[64];
    ALIGN64 uint8_t tempDst[64];
	ALIGN64 sso_ZucKey4_t keys; /* structure to store the 4 keys */
    ALIGN64 ssoZucIv4_t ivs;    /* strucutre to store the 4 IV's */
    uint32_t numBytesLeftOver = 0;
    uint8_t *pTempBufInPtr = NULL;
    uint8_t *pTempBufOutPtr = NULL;

    uint64_t *pIn64_0 = NULL, *pOut64_0 = NULL;
    uint64_t *pIn64_1 = NULL, *pOut64_1 = NULL;
    uint64_t *pIn64_2 = NULL, *pOut64_2 = NULL;
    uint64_t *pIn64_3 = NULL, *pOut64_3 = NULL;
    uint64_t *pTempSrc64 = NULL;
    uint64_t *pTempDst64 = NULL;
    uint64_t *pKeyStream64 = NULL;


#ifdef DEBUG
    uint32_t * pTemp = NULL;
#endif


    /* rounded down minimum length */
    bytes = numKeyStreamsPerPacket * ZUC_KEYSTREAM_LENGTH_PER_ITERATION;

    /* Need to set the LFSR state to zero */
    memset(&state, 0, sizeof(ssoZucState4_t));

    DEBUG_PRINT("Number of 64-byte KeyStreams: %d\n", numKeyStreamsPerPacket);

    /* Calculate the number of bytes left over for each packet */
    for(i=0; i< 4; i++)
    {
        leftOverBytesInPacket[i] = lengthInBytes[i] - bytes;
    }

    /* Setup the Keys */
    keys.pKey1 = pKey[0];
    keys.pKey2 = pKey[1];
    keys.pKey3 = pKey[2];
    keys.pKey4 = pKey[3];

    /* setup the IV's */
    ivs.pIv1 = pIv[0];
    ivs.pIv2 = pIv[1];
    ivs.pIv3 = pIv[2];
    ivs.pIv4 = pIv[3];

#if (defined(__AVX__))
	asm_ZucInitialization_4( &keys,  &ivs, &state);
#else
	asm_ZucInitialization( keys.pKey1,  ivs.pIv1, &state[0]);
	asm_ZucInitialization( keys.pKey2,  ivs.pIv2, &state[1]);
	asm_ZucInitialization( keys.pKey3,  ivs.pIv3, &state[2]);
	asm_ZucInitialization( keys.pKey4,  ivs.pIv4, &state[3]);
#endif

    pOut64_0 = (uint64_t *) pBufferOut[0];
    pOut64_1 = (uint64_t *) pBufferOut[1];
    pOut64_2 = (uint64_t *) pBufferOut[2];
    pOut64_3 = (uint64_t *) pBufferOut[3];

    pIn64_0 = (uint64_t *) pBufferIn[0];
    pIn64_1 = (uint64_t *) pBufferIn[1];
    pIn64_2 = (uint64_t *) pBufferIn[2];
    pIn64_3 = (uint64_t *) pBufferIn[3];


    /* Loop for 64 bytes at a time generating 4 key-streams per loop */
    while (numKeyStreamsPerPacket)
    {
        /* Generate 64 bytes at a time */
#if (defined(__AVX__))
		asm_ZucGenKeystream64B_4(&state,
                                 (uint32_t *) keyStr1,
                                 (uint32_t *) keyStr2,
                                 (uint32_t *) keyStr3,
                                 (uint32_t *) keyStr4);
#else
		asm_ZucGenKeystream64B((uint32_t *) &keyStr1, &state[0]);
		asm_ZucGenKeystream64B((uint32_t *) &keyStr2, &state[1]);
		asm_ZucGenKeystream64B((uint32_t *) &keyStr3, &state[2]);
		asm_ZucGenKeystream64B((uint32_t *) &keyStr4, &state[3]);
#endif

#ifdef DEBUG
    pTemp = (uint32_t *) keyStr1;
    DEBUG_PRINT("Key-Stream: ");
    DEBUG_PRINT(" 0x%8x 0x%8x \n", pTemp[0], pTemp[1]);
#endif



        /* XOR the KeyStream with the input buffers and store in output buffer*/
        pKeyStream64 = (uint64_t *) keyStr1;
        SSO_ZUC_XOR_KEYSTREAM(pIn64_0, pOut64_0, pKeyStream64);

        pKeyStream64 = (uint64_t *) keyStr2;
        SSO_ZUC_XOR_KEYSTREAM(pIn64_1, pOut64_1, pKeyStream64);

        pKeyStream64 = (uint64_t *) keyStr3;
        SSO_ZUC_XOR_KEYSTREAM(pIn64_2, pOut64_2, pKeyStream64);

        pKeyStream64 = (uint64_t *) keyStr4;
        SSO_ZUC_XOR_KEYSTREAM(pIn64_3, pOut64_3, pKeyStream64);


        /* Update keystream count */
        numKeyStreamsPerPacket--;

    }



    /* process each packet separately for the remaining bytes */
    for(i=0; i<4; i++)
    {
        if(leftOverBytesInPacket[i])
        {
#if( defined(__AVX__))
            /* need to copy the zuc state to single packet state */
            singlePacketState.lfsrState[0] = state.lfsrState[0][i];
            singlePacketState.lfsrState[1] = state.lfsrState[1][i];
            singlePacketState.lfsrState[2] = state.lfsrState[2][i];
            singlePacketState.lfsrState[3] = state.lfsrState[3][i];
            singlePacketState.lfsrState[4] = state.lfsrState[4][i];
            singlePacketState.lfsrState[5] = state.lfsrState[5][i];
            singlePacketState.lfsrState[6] = state.lfsrState[6][i];
            singlePacketState.lfsrState[7] = state.lfsrState[7][i];
            singlePacketState.lfsrState[8] = state.lfsrState[8][i];
            singlePacketState.lfsrState[9] = state.lfsrState[9][i];
            singlePacketState.lfsrState[10] = state.lfsrState[10][i];
            singlePacketState.lfsrState[11] = state.lfsrState[11][i];
            singlePacketState.lfsrState[12] = state.lfsrState[12][i];
            singlePacketState.lfsrState[13] = state.lfsrState[13][i];
            singlePacketState.lfsrState[14] = state.lfsrState[14][i];
            singlePacketState.lfsrState[15] = state.lfsrState[15][i];

            singlePacketState.fR1 = state.fR1[i];
            singlePacketState.fR2 = state.fR2[i];

            singlePacketState.bX0 = state.bX0[i];
            singlePacketState.bX1 = state.bX1[i];
            singlePacketState.bX2 = state.bX2[i];
            singlePacketState.bX3 = state.bX3[i];
#else
            /* need to copy the zuc state to single packet state */
            singlePacketState.lfsrState[0] = state[i].lfsrState[0];
            singlePacketState.lfsrState[1] = state[i].lfsrState[1];
            singlePacketState.lfsrState[2] = state[i].lfsrState[2];
            singlePacketState.lfsrState[3] = state[i].lfsrState[3];
            singlePacketState.lfsrState[4] = state[i].lfsrState[4];
            singlePacketState.lfsrState[5] = state[i].lfsrState[5];
            singlePacketState.lfsrState[6] = state[i].lfsrState[6];
            singlePacketState.lfsrState[7] = state[i].lfsrState[7];
            singlePacketState.lfsrState[8] = state[i].lfsrState[8];
            singlePacketState.lfsrState[9] = state[i].lfsrState[9];
            singlePacketState.lfsrState[10] = state[i].lfsrState[10];
            singlePacketState.lfsrState[11] = state[i].lfsrState[11];
            singlePacketState.lfsrState[12] = state[i].lfsrState[12];
            singlePacketState.lfsrState[13] = state[i].lfsrState[13];
            singlePacketState.lfsrState[14] = state[i].lfsrState[14];
            singlePacketState.lfsrState[15] = state[i].lfsrState[15];

            singlePacketState.fR1 = state[i].fR1;
            singlePacketState.fR2 = state[i].fR2;

            singlePacketState.bX0 = state[i].bX0;
            singlePacketState.bX1 = state[i].bX1;
            singlePacketState.bX2 = state[i].bX2;
            singlePacketState.bX3 = state[i].bX3;

#endif


            numKeyStreamsPerPacket = leftOverBytesInPacket[i] / ZUC_KEYSTREAM_LENGTH_PER_ITERATION;
            numBytesLeftOver = leftOverBytesInPacket[i]  % ZUC_KEYSTREAM_LENGTH_PER_ITERATION;

            DEBUG_PRINT("Packet:                 %d     Left Over Bytes:  %d\n", i, leftOverBytesInPacket[i]);
            DEBUG_PRINT("numKeyStreamsPerPacket: %d     numBytesLeftOver: %d\n",numKeyStreamsPerPacket, numBytesLeftOver);


            pTempBufInPtr = pBufferIn[i];
            pTempBufOutPtr = pBufferOut[i];


            /* update the output and input pointers here to point to the i'th buffers */
            pOut64_0 = (uint64_t *) &pTempBufOutPtr[lengthInBytes[i] - leftOverBytesInPacket[i]];
            pIn64_0 = (uint64_t *) &pTempBufInPtr[lengthInBytes[i] - leftOverBytesInPacket[i]];


            while(numKeyStreamsPerPacket--)
            {
                /* Generate the key stream 64 bytes at a time */
                asm_ZucGenKeystream64B((uint32_t *) keyStr1,
                                        &singlePacketState);
                pKeyStream64 = (uint64_t *) keyStr1;
                SSO_ZUC_XOR_KEYSTREAM(pIn64_0, pOut64_0 ,pKeyStream64);
            }


            /* Check for remaining 0 to 7 bytes */
            if(numBytesLeftOver)
            {

               asm_ZucGenKeystream64B((uint32_t *) &keyStr1,
                                                       &singlePacketState);

               /* copy the remaining bytes into temporary buffer and XOR with the
                * 64-bytes of keystream. Then copy on the valid bytes back to the
                * output buffer */
               memcpy(&tempSrc[0], &pTempBufInPtr[lengthInBytes[i] - numBytesLeftOver],numBytesLeftOver);
               memset(&tempSrc[numBytesLeftOver], 0, 64 - numBytesLeftOver);

               pKeyStream64 = (uint64_t *) &keyStr1[0];
               pTempSrc64 = (uint64_t *) &tempSrc[0];
               pTempDst64 = (uint64_t *) &tempDst[0];
               SSO_ZUC_XOR_KEYSTREAM(pTempSrc64, pTempDst64 ,pKeyStream64);

               memcpy(&pTempBufOutPtr[lengthInBytes[i] - numBytesLeftOver], &tempDst[0], numBytesLeftOver);


            }
        }
    }

}/* end sso_zuc_4_buffer */






__attribute__((gnu_inline)) inline void sso_zuc_eea3_n_buffer(uint8_t *pKey[], uint8_t *pIv[],
                      uint8_t *pBufferIn[], uint8_t *pBufferOut[],
                      uint32_t lengthInBytes[], uint32_t numBuffers)
{

    int i =0;
    int packetCount = numBuffers;

#if (defined(__AVX__))
	/* process 4 packets in parallel */
    while(packetCount >= 4)
    {
        packetCount -=4;
        sso_zuc_eea3_4_buffer(&pKey[i],
                         &pIv[i],
                         &pBufferIn[i],
                         &pBufferOut[i],
                         &lengthInBytes[i]);
        i+=4;
    }
#else
    while(packetCount >= 4)
    {
        packetCount -=4;
        sso_zuc_eea3_1_buffer(pKey[i],
                         pIv[i],
                         pBufferIn[i],
                         pBufferOut[i],
                         lengthInBytes[i]);
        sso_zuc_eea3_1_buffer(pKey[i+1],
                         pIv[i+1],
                         pBufferIn[i+1],
                         pBufferOut[i+1],
                         lengthInBytes[i+1]);
        sso_zuc_eea3_1_buffer(pKey[i+2],
                         pIv[i+2],
                         pBufferIn[i+2],
                         pBufferOut[i+2],
                         lengthInBytes[i+2]);
        sso_zuc_eea3_1_buffer(pKey[i+3],
                         pIv[i+3],
                         pBufferIn[i+3],
                         pBufferOut[i+3],
                         lengthInBytes[i+3]);
        i+=4;
    }

#endif
    while(packetCount--)
    {
        sso_zuc_eea3_1_buffer((uint8_t *) pKey[i],
                         (uint8_t *) pIv[i],
                         (uint8_t *) pBufferIn[i],
                         (uint8_t *) pBufferOut[i],
                         lengthInBytes[i]);
        i++;
    }

}/* end sso_zuc_n_buffer */



static inline void sso_get_cpuid(uint32_t *pResult, uint32_t eax, uint32_t ecx)
{
    __asm__("\ncpuid\n" : "=a" (pResult[0]),
                          "=b" (pResult[1]),
                          "=c" (pResult[2]),
                          "=d" (pResult[3]):
                          "0" (eax),
                          "2" (ecx));
    return ;
}



uint32_t sso_zuc_cpuid_check(void)
{
    uint32_t result[4];


    sso_get_cpuid(result, 1, 0);

    return (!(result[2] & (1<<19))) ;   /*SSE4_1:ECX:19 */
}/*end sso_zuc_cpuid_check*/







__attribute__((gnu_inline)) inline  void sso_zuc_eia3_1_buffer(uint8_t *pKey,
                                  uint8_t *pIv,
                                  uint8_t *pBufferIn,
                                  uint32_t lengthInBits,
                                  uint32_t *pMacI)
{
    uint32_t N=0, T=0, L=0, keyStreamLengthInBytes, i =0;
    ALIGN64 ssoZucState_t zucState;
    ALIGN64 uint8_t keyStream[64];
    uint32_t keyStreamLengthInBits = 0, noOfBits=0;
    /* generate a key-stream 2 words longer than the input message */
    N = lengthInBits + 2*ZUC_WORD;
    L = (N+31)/ZUC_WORD;
    keyStreamLengthInBytes = (N+7) / 8;

    if(keyStreamLengthInBytes < ZUC_KEYSTREAM_LENGTH_PER_ITERATION)
    {
        keyStreamLengthInBytes = ZUC_KEYSTREAM_LENGTH_PER_ITERATION;
    }

    memset(&zucState, 0, sizeof(ssoZucState_t));

    DEBUG_PRINT("Input Length in Bits:      %d \n", lengthInBits);
    DEBUG_PRINT("KeyStream to be generated: %d \n", keyStreamLengthInBytes);
    DEBUG_PRINT("L:                         %d\n", L);
    DEBUG_PRINT("N:                         %d\n", N);



    noOfBits = lengthInBits;

    uint32_t *pZuc = (uint32_t *) &keyStream[0];
    uint8_t *pData = pBufferIn;
    uint32_t bitOffset = 0, wordOffset =0, keyResidue = 0, keyResidue2 = 0;

    asm_ZucInitialization(pKey, pIv, &(zucState));
    keyStreamLengthInBits = ZUC_KEYSTREAM_LENGTH_PER_ITERATION*8;
    DEBUG_PRINT("keyStreamLengthInBits: %d\n", keyStreamLengthInBits);
    /* loop over the message bits */
	asm_ZucGenKeystream64B(pZuc, &zucState);
    while (noOfBits)
    {
     DEBUG_PRINT("LengthInBits: %d\n", lengthInBits);
     DEBUG_PRINT("L: %d\n", L);
       /* Generate the key stream 64 bytes at a time */

        if(noOfBits < keyStreamLengthInBits)
        {
            for(i=0; i < noOfBits; i++)
            {
                bitOffset = i%32;        /* The bit position offset into the 32-bit word */
                wordOffset = i/32;       /* 32-bit word offset */
		if (wordOffset  == 15) {
						if (bitOffset == 0) {
							keyResidue = pZuc[15];
							asm_ZucGenKeystream64B(pZuc, &zucState);
						}
				}
                if(pData[i/8] & ( 0x80 >>(bitOffset%8)))
                {
		    if (wordOffset  == 15) {
						T ^= (keyResidue<<bitOffset) | (uint32_t)(((uint64_t)pZuc[0])>>(32-bitOffset));
	            } else
                        T ^= (pZuc[wordOffset]<<bitOffset) | (uint32_t)(((uint64_t)pZuc[wordOffset+1])>>(32-bitOffset));
                }
            }
	    if (wordOffset  == 14){//for pZuc[L-1]
                keyResidue = pZuc[14];
                keyResidue2 = pZuc[15];
				asm_ZucGenKeystream64B(pZuc, &zucState);
                            
		if(bitOffset==31){//just 480 bits
			pZuc[1] =  pZuc[0];
			pZuc[0] = keyResidue2;
			lengthInBits=0;
			L = 2;
		}else{
                	pZuc[2] = pZuc[0];
                	pZuc[1] = keyResidue2;
                	pZuc[0] = keyResidue;
                	lengthInBits =  lengthInBits%32;
                	L = 3;
		}
            }
	    if (wordOffset  == 15)
            {
                pZuc[2] = pZuc[1];
                pZuc[1] = pZuc[0];
                pZuc[0] = keyResidue;
                lengthInBits =  lengthInBits%32;
                L = 3;
            }
            noOfBits = 0;
        }
        else
        {
            /* run for 64Bytes of key stream only */
            for(i=0; i < keyStreamLengthInBits; i++)
            {
                bitOffset = i%32;        /* The bit position offset into the 32-bit word */
                wordOffset = i/32;       /* 32-bit word offset */
				if (wordOffset  == 15) {
						if (bitOffset == 0) {
							keyResidue = pZuc[15];
							asm_ZucGenKeystream64B(pZuc, &zucState);
						}
				}
                if (pData[i/8] & (0x80 >> (bitOffset%8)))
				{
					if (wordOffset  == 15) {
						T ^= (keyResidue<<bitOffset) | (uint32_t)(((uint64_t)pZuc[0])>>(32-bitOffset));
					} else 
						T ^= (pZuc[wordOffset]<<bitOffset) | (uint32_t)(((uint64_t)pZuc[wordOffset+1])>>(32-bitOffset));
                }
            }
			noOfBits -= keyStreamLengthInBits;
			pData = &pData[ZUC_KEYSTREAM_LENGTH_PER_ITERATION];
			lengthInBits -=  keyStreamLengthInBits;
			L -= ZUC_KEYSTREAM_LENGTH_PER_ITERATION/4;
        }
    }/* while end */

    bitOffset = lengthInBits%32;        /* The bit position offset into the 32-bit word */
    wordOffset = lengthInBits/32;       /* 32-bit word offset */
    T ^= (pZuc[wordOffset]<<bitOffset) | (uint32_t)(((uint64_t)pZuc[wordOffset+1])>>(32-bitOffset));

    /* save the final MAC-I result */
    *pMacI = __builtin_bswap32(T ^ pZuc[L-1]);



}

