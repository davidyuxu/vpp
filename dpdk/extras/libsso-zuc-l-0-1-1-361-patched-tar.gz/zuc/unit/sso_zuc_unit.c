/***************************************************************************
*
* INTEL CONFIDENTIAL
* Copyright 2009-2013 Intel Corporation All Rights Reserved.
* 
* The source code contained or described herein and all documents related to the
* source code ("Material") are owned by Intel Corporation or its suppliers or
* licensors. Title to the Material remains with Intel Corporation or its
* suppliers and licensors. The Material may contain trade secrets and proprietary
* and confidential information of Intel Corporation and its suppliers and
* licensors, and is protected by worldwide copyright and trade secret laws and
* treaty provisions. No part of the Material may be used, copied, reproduced,
* modified, published, uploaded, posted, transmitted, distributed, or disclosed
* in any way without Intels prior express written permission.
* No license under any patent, copyright, trade secret or other intellectual
* property right is granted to or conferred upon you by disclosure or delivery
* of the Materials, either expressly, by implication, inducement, estoppel or
* otherwise. Any license under such intellectual property rights must be
* express and approved by Intel in writing.
* 
* Include any supplier copyright notices as supplier requires Intel to use.
* Include supplier trademarks or logos as supplier requires Intel to use,
* preceded by an asterisk.
* An asterisked footnote can be added as follows: 
*   *Third Party trademarks are the property of their respective owners.
* 
* Unless otherwise agreed by Intel in writing, you may not remove or alter this
* notice or any other notice embedded in Materials by Intel or Intels suppliers
* or licensors in any way.
* 
*  version: LIBSSO_ZUC.L.0.1.1-361
*
***************************************************************************/

/*-----------------------------------------------------------------------
* Zuc functional test
*-----------------------------------------------------------------------
*
* A simple functional test for ZUC
*
*-----------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>

#include "sso_zuc.h"
#include "sso_zuc_internal.h"
#include "sso_common.h"
#include "sso_utils.h"
#include "sso_zuc_test_vectors.h"

#include "xmmintrin.h"


#define MAXBUFS 16
#define PASS_STATUS 0
#define FAIL_STATUS -1

int validate_sso_zuc_algorithm( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV);
int validate_sso_zuc_EEA_1_block( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV);
int validate_sso_zuc_EEA_4_block( uint8_t **pSrcData, uint8_t **pDstData, uint8_t **pKeys, uint8_t **pIV);
int validate_sso_zuc_EEA_n_block( uint8_t **pSrcData, uint8_t **pDstData, uint8_t **pKeys, uint8_t **pIV, uint32_t numBuffs);
int validate_sso_zuc_EIA_1_block( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV);
static void sso_hexdump(char* message, const uint8_t *ptr, int len);


/******************************************************************************
 * @ingroup zuc_functionalTest_app
 *
 * @description
 * This function allocates memory for buffers and set random data in each buffer
 *
 * pSrcData = pointers to the new source buffers
 * numOfBuffs = number of buffers
 * ************************************************/
uint32_t createSourceData(uint8_t *pSrcData[MAXBUFS], uint32_t numOfBuffs)
{
	uint32_t i = 0, j = 0;

	for(i = 0;i < numOfBuffs;i++)
	{
		pSrcData[i] = (uint8_t*) _mm_malloc(MAX_BUFFER_LENGTH_IN_BYTES,64);

		if(!pSrcData[i])
		{
			printf("_mm_malloc(pSrcData[i]): failed!\n");

			for(j = 0;j < i;j++)
			{
				_mm_free(pSrcData[j]);
				pSrcData[j] = NULL;
			}

			return FAIL_STATUS;
		}
	}
	return PASS_STATUS;
}

/******************************************************************************
 * @ingroup zuc_functionalTest_app
 *
 * @description
 * This function creates source data and vector buffers.
 *
 * keyLen = key length
 * pKeys = array of pointers to the new key buffers
 * ivLen = vector length
 * pIV = array of pointers to the new vector buffers
 * numOfBuffs = number of buffers
************************************************/
uint32_t createKeyVecData(uint32_t keyLen, uint8_t *pKeys[MAXBUFS],
						  uint32_t ivLen, uint8_t *pIV[MAXBUFS],
						  uint32_t numOfBuffs)
{
	uint32_t i = 0, j = 0;

	for(i = 0;i < numOfBuffs;i++)
	{
		pIV[i] = (uint8_t *)_mm_malloc(ivLen, 64);

		if(!pIV[i])
		{
			printf("_mm_malloc(pIV[i]): failed!\n");

			for(j = 0;j < i;j++)
			{
				_mm_free(pIV[j]);
				_mm_free(pKeys[j]);
			}

			return FAIL_STATUS;
		}

		pKeys[i] = _mm_malloc(keyLen, 64);

		if(!pKeys[i])
		{
			printf("_mm_malloc(pKeys[i]): failed!\n");

			for(j = 0;j <= i;j++)
			{
				_mm_free(pIV[j]);

				if(j < i)
				{
					_mm_free(pKeys[j]);
				}
			}
			return FAIL_STATUS;
		}
	}

	return PASS_STATUS;
}

/******************************************************************************
 * @ingroup zuc_benchmark_app
 *
 * @description
 * This function free memory pointed to by an array of pointers
 *
 * arr = array of memory pointers
 * length = length of pointer array (or number of pointers whose buffers
 * should be freed)
 * ************************************************/
void freePtrArray(uint8_t *pArr[MAXBUFS], uint32_t arrayLength)
{
	uint32_t i = 0;

	for(i = 0;i < arrayLength;i++)
	{
		_mm_free(pArr[i]);
	}
}

int main(int argc, char ** argv)
{
	uint32_t numBuffs = 9, i, a;
	uint32_t status = PASS_STATUS;
	uint8_t *pKeys[MAXBUFS];
	uint8_t* pIV[MAXBUFS];
	uint8_t* pSrcData[MAXBUFS];
	uint8_t* pDstData[MAXBUFS];



	if(sso_zuc_cpuid_check())
	{
		printf("sso_zuc_cpuid_check(): Failed \n");
//		return FAIL_STATUS;
	}

	printf("Running Functional Tests\n");
	fflush(stdout);


		/*Create test data buffers + populate with random data*/
		if(createSourceData(pSrcData, numBuffs))
		{
			printf("createSourceData() error \n");
			return FAIL_STATUS;
		}
		if(createSourceData(pDstData, numBuffs))
		{
			printf("createSourceData() error \n");
			return FAIL_STATUS;
		}

		/*Create random keys and vectors*/
		if(createKeyVecData(ZUC_KEY_LEN_IN_BYTES, pKeys, ZUC_IV_LEN_IN_BYTES,
							pIV, 9))
		{
			printf("createKeyVecData() error \n");
			for(i=0; i < numBuffs; i++)/*MAXBUFS*/
			{
				_mm_free(pSrcData[i]);
			}
			return FAIL_STATUS;
		}

#if 1
		if (validate_sso_zuc_algorithm(pSrcData[0], pSrcData[0], pKeys[0], pIV[0]))
		{
			status = 1;
		} else {
			printf("validate ZUC algorithm: PASS\n");
		}

#endif
#if 1
		if (validate_sso_zuc_EEA_1_block(pSrcData[0], pSrcData[0], pKeys[0], pIV[0]))
		{
			status = 1;
		}else {
			printf("validate ZUC 1 block: PASS\n");
		}
#endif
#if 1
		if (validate_sso_zuc_EEA_4_block( pSrcData, pSrcData, pKeys, pIV))
		{
			status = 1;
		} else {
			printf("validate ZUC 4 block: PASS\n");
		}
#endif
#if 1
	for (a = 0; a < 3; a++)
	{
		switch(a)
		{
			case 0: numBuffs = 4;break;
			case 1: numBuffs = 8;break;
			default: numBuffs = 9;break;
		}
		if (validate_sso_zuc_EEA_n_block(pSrcData, pDstData, pKeys, pIV, numBuffs))
		{
			status = 1;
		} else {
			printf("validate ZUC n block buffers %d: PASS\n",a);
		}
	}
	
#endif
#if 1
		if(validate_sso_zuc_EIA_1_block( pSrcData[0], pDstData[0], pKeys[0], pIV[0])){
			status = 1;
			} else 
				printf("validate ZUC Integrity 1 block: PASS\n");
#endif
	freePtrArray(pKeys, 9);/*Free the key buffers*/
		freePtrArray(pIV, 9);/*Free the vector buffers*/
		freePtrArray(pSrcData, 9);/*Free the source buffers*/
		if (status) {
			return status;
		}

	printf("The Functional Test aplication completed\n");
	return 0;
}

int validate_sso_zuc_EEA_1_block( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV){
	uint32_t i, byteResidue, retTmp;
	uint32_t ret = 0;
	uint32_t byteLength;
	uint32_t bitResidue;
	union IV_t {
		uint8_t IVb[ZUC_IV_LEN_IN_BYTES];
		uint32_t IVw[ZUC_IV_LEN_IN_BYTES/sizeof(uint32_t)];
		uint64_t IVl[ZUC_IV_LEN_IN_BYTES/sizeof(uint64_t)];
	} IVprep;
	for (i = 0;i < NUM_ZUC_EEA3_TESTS; i++)
	{
		memcpy(pKeys,testEEA3_vectors[i].CK, ZUC_KEY_LEN_IN_BYTES);
		IVprep.IVl[0] = IVprep.IVl[1] = 0;
		IVprep.IVw[2] = IVprep.IVw[0] = __builtin_bswap32(testEEA3_vectors[i].count);
		IVprep.IVb[4] = IVprep.IVb[12] = (testEEA3_vectors[i].Bearer << 3) | (testEEA3_vectors[i].Direction << 2);
		memcpy(pIV, IVprep.IVb , ZUC_IV_LEN_IN_BYTES);
		byteLength = (testEEA3_vectors[i].length_in_bits +7)/8;
		memcpy(pSrcData, testEEA3_vectors[i].plaintext, byteLength);
		sso_zuc_eea3_1_buffer( pKeys, pIV, pSrcData, pDstData, byteLength);
		retTmp = memcmp( pDstData, testEEA3_vectors[i].ciphertext,byteLength - 1);
		if (retTmp) {
			printf("Validate ZUC 1 block  test %d (Enc): FAIL\n",i+1);
			sso_hexdump("Expected", testEEA3_vectors[i].ciphertext, byteLength);
			sso_hexdump("Found", pDstData, byteLength);
			ret = retTmp;
			//return ret;
		} else {
			bitResidue = (0xFF00 >> (testEEA3_vectors[i].length_in_bits % 8)) & 0x00FF;
			byteResidue = (testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8] ^ pDstData[testEEA3_vectors[i].length_in_bits/8]) & bitResidue;
			if (byteResidue) {
				printf("Validate ZUC 1 block  test %d (Enc): FAIL\n",i+1);
				printf("Expected: 0x%02X (last byte)\n", 0xFF & testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8]);
				printf("Found: 0x%02X (last byte)\n", 0xFF & pDstData[testEEA3_vectors[i].length_in_bits/8]);
			} else
				printf("Validate ZUC 1 block  test %d (Enc): PASS\n",i+1);
		}
		fflush(stdout);
	}
	return ret;
};
int validate_sso_zuc_EEA_4_block( uint8_t **pSrcData, uint8_t **pDstData, uint8_t **pKeys, uint8_t **pIV){

	uint32_t i,j, packetLen[4], ret = 0, retTmp, bitResidue, byteResidue;
	union IV_t {
		uint8_t IVb[ZUC_IV_LEN_IN_BYTES];
		uint32_t IVw[ZUC_IV_LEN_IN_BYTES/sizeof(uint32_t)];
		uint64_t IVl[ZUC_IV_LEN_IN_BYTES/sizeof(uint64_t)];
	} IVprep;

	for (i = 0;i < NUM_ZUC_EEA3_TESTS; i++)
	{ 
		for (j=0; j < 4; j++) {
			packetLen[j] = (testEEA3_vectors[i].length_in_bits +7)/8;
			memcpy(pKeys[j], testEEA3_vectors[i].CK, ZUC_KEY_LEN_IN_BYTES);
			IVprep.IVl[0] = IVprep.IVl[1] = 0;
			IVprep.IVw[2] = IVprep.IVw[0] = __builtin_bswap32(testEEA3_vectors[i].count);
			IVprep.IVb[4] = IVprep.IVb[12] = (testEEA3_vectors[i].Bearer << 3) | (testEEA3_vectors[i].Direction << 2);
			memcpy(pIV[j], IVprep.IVb , ZUC_IV_LEN_IN_BYTES);
			memcpy(pSrcData[j], testEEA3_vectors[i].plaintext, packetLen[j]);
		}
		sso_zuc_eea3_4_buffer(pKeys, pIV, pSrcData, pDstData,packetLen);
		retTmp = memcmp( pDstData[0], testEEA3_vectors[i].ciphertext,(testEEA3_vectors[i].length_in_bits)/8);
		if (retTmp) {
			printf("Validate ZUC 4 block (Enc) test %d: FAIL\n",i+1);
			sso_hexdump("Expected", testEEA3_vectors[i].ciphertext, (testEEA3_vectors[i].length_in_bits + 7)/8);
			sso_hexdump("Found", pDstData[0], (testEEA3_vectors[i].length_in_bits + 7)/8);
			ret = retTmp;
			//return ret;
		} else {
			bitResidue = (0xFF00 >> (testEEA3_vectors[i].length_in_bits % 8)) & 0x00FF;
			byteResidue = (testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8] ^ pDstData[0][testEEA3_vectors[i].length_in_bits/8]) & bitResidue;
			if (byteResidue) {
				ret = 1;
				printf("Validate ZUC 4 block  test %d (Enc): FAIL\n",i+1);
				printf("Expected: 0x%02X (last byte)\n", 0xFF & testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8]);
				printf("Found: 0x%02X (last byte)\n", 0xFF & pDstData[0][testEEA3_vectors[i].length_in_bits/8]);
			} else
				printf("Validate ZUC 4 block  test %d (Enc): PASS\n",i+1);
		}
		fflush(stdout);
		for (j=0; j<4; j++) {
			memcpy(pSrcData[j], testEEA3_vectors[i].ciphertext, (testEEA3_vectors[i].length_in_bits +7)/8);
		}
		sso_zuc_eea3_4_buffer(pKeys, pIV, pSrcData, pDstData,packetLen);
		retTmp = memcmp( pDstData[0], testEEA3_vectors[i].plaintext,(testEEA3_vectors[i].length_in_bits)/8);
		if (retTmp) {
			printf("Validate ZUC 4 block (Dec) test %d: FAIL\n",i+1);
			sso_hexdump("Expected", testEEA3_vectors[i].plaintext, (testEEA3_vectors[i].length_in_bits + 7)/8);
			sso_hexdump("Found", pDstData[0], (testEEA3_vectors[i].length_in_bits + 7)/8);
			ret = retTmp;
			//return ret;
		} else {
			bitResidue = (0xFF00 >> (testEEA3_vectors[i].length_in_bits % 8)) & 0x00FF;
			byteResidue = (testEEA3_vectors[i].plaintext[testEEA3_vectors[i].length_in_bits/8] ^ pDstData[0][testEEA3_vectors[i].length_in_bits/8]) & bitResidue;
			if (byteResidue) {
				ret = 1;
				printf("Validate ZUC 4 block  test %d (Dec): FAIL\n",i+1);
				printf("Expected: 0x%02X (last byte)\n", 0xFF & testEEA3_vectors[i].plaintext[testEEA3_vectors[i].length_in_bits/8]);
				printf("Found: 0x%02X (last byte)\n", 0xFF & pDstData[0][testEEA3_vectors[i].length_in_bits/8]);
			} else
				printf("Validate ZUC 4 block  test %d (Dec): PASS\n",i+1);
		}
		fflush(stdout);
	}
return ret;
};
int validate_sso_zuc_EEA_n_block( uint8_t **pSrcData, uint8_t **pDstData, uint8_t **pKeys, uint8_t **pIV, uint32_t numBuffs){
	uint32_t i,j, ret = 0, retTmp, bitResidue, byteResidue, packetLen[numBuffs];
	union IV_t {
		uint8_t IVb[ZUC_IV_LEN_IN_BYTES];
		uint32_t IVw[ZUC_IV_LEN_IN_BYTES/sizeof(uint32_t)];
		uint64_t IVl[ZUC_IV_LEN_IN_BYTES/sizeof(uint64_t)];
	} IVprep;

	assert(numBuffs > 0);
	for (i = 0;i < NUM_ZUC_EEA3_TESTS; i++)
	{
		for (j=0; j <= (numBuffs - 1); j++) {
			memcpy(pKeys[j], testEEA3_vectors[i].CK, ZUC_KEY_LEN_IN_BYTES);
			IVprep.IVl[0] = IVprep.IVl[1] = 0;
			IVprep.IVw[2] = IVprep.IVw[0] = __builtin_bswap32(testEEA3_vectors[i].count);
			IVprep.IVb[4] = IVprep.IVb[12] = (testEEA3_vectors[i].Bearer << 3) | (testEEA3_vectors[i].Direction << 2);
			memcpy(pIV[j], IVprep.IVb , ZUC_IV_LEN_IN_BYTES);
			memcpy(pSrcData[j], testEEA3_vectors[i].plaintext, (testEEA3_vectors[i].length_in_bits +7)/8);
			packetLen[j] = (testEEA3_vectors[i].length_in_bits +7)/8;
		}
		sso_zuc_eea3_n_buffer(pKeys, pIV, pSrcData, pDstData, packetLen, numBuffs);
		retTmp = memcmp( pDstData[0], testEEA3_vectors[i].ciphertext,(testEEA3_vectors[i].length_in_bits)/8);
		if (retTmp) {
			printf("Validate ZUC n block (Enc) test %d, buffers: %d: FAIL\n",i+1,numBuffs);
			sso_hexdump("Expected", testEEA3_vectors[i].ciphertext, (testEEA3_vectors[i].length_in_bits + 7)/8);
			sso_hexdump("Found", pDstData[0], (testEEA3_vectors[i].length_in_bits + 7)/8);
			ret = retTmp;
			//return ret;
		} else {
			bitResidue = (0xFF00 >> (testEEA3_vectors[i].length_in_bits % 8)) & 0x00FF;
			byteResidue = (testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8] ^ pDstData[0][testEEA3_vectors[i].length_in_bits/8]) & bitResidue;
			if (byteResidue) {
				ret = 1;
				printf("Validate ZUC n block (Enc)  test %d, buffers %d: FAIL\n",i+1, numBuffs);
				printf("Expected: 0x%02X (last byte)\n", 0xFF & testEEA3_vectors[i].ciphertext[testEEA3_vectors[i].length_in_bits/8]);
				printf("Found: 0x%02X (last byte)\n", 0xFF & pDstData[0][testEEA3_vectors[i].length_in_bits/8]);
			} else
				printf("Validate ZUC n block (Enc)  test %d, buffers %d: PASS\n",i+1, numBuffs);
		}
		fflush(stdout);
		for (j=0; j<= (numBuffs -1); j++) {
			memcpy(pSrcData[j], testEEA3_vectors[i].ciphertext, (testEEA3_vectors[i].length_in_bits +7)/8);
		}
		sso_zuc_eea3_n_buffer(pKeys, pIV, pSrcData, pDstData,packetLen, numBuffs);
		retTmp =  memcmp( pDstData[0], testEEA3_vectors[i].plaintext,(testEEA3_vectors[i].length_in_bits)/8);
		if (retTmp) {
			printf("Validate ZUC n block (Dec) test %d, buffers %d: FAIL\n",i+1, numBuffs);
			sso_hexdump("Expected", testEEA3_vectors[i].plaintext, (testEEA3_vectors[i].length_in_bits + 7)/8);
			sso_hexdump("Found", pDstData[0], (testEEA3_vectors[i].length_in_bits + 7)/8);
			ret = retTmp;
			//return ret;
		} else {
			bitResidue = (0xFF00 >> (testEEA3_vectors[i].length_in_bits % 8)) & 0x00FF;
			byteResidue = (testEEA3_vectors[i].plaintext[testEEA3_vectors[i].length_in_bits/8] ^ pDstData[0][testEEA3_vectors[i].length_in_bits/8]) & bitResidue;
			if (byteResidue) {
				ret = 1;
				printf("Validate ZUC n block (Dec) test %d, buffers %d : FAIL\n",i+1, numBuffs);
				printf("Expected: 0x%02X (last byte)\n", 0xFF & testEEA3_vectors[i].plaintext[testEEA3_vectors[i].length_in_bits/8]);
				printf("Found: 0x%02X (last byte)\n", 0xFF & pDstData[0][testEEA3_vectors[i].length_in_bits/8]);
			} else
				printf("Validate ZUC n block (Dec) test %d, buffers %d: PASS\n",i+1,numBuffs);
		}
		fflush(stdout);
	}
	return ret;
};
int validate_sso_zuc_EIA_1_block( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV){
	uint32_t i, retTmp;
	uint32_t ret = 0;
	uint32_t byteLength;
	union IV_t {
		uint8_t IVb[ZUC_IV_LEN_IN_BYTES];
		uint32_t IVw[ZUC_IV_LEN_IN_BYTES/sizeof(uint32_t)];
		uint64_t IVl[ZUC_IV_LEN_IN_BYTES/sizeof(uint64_t)];
	} IVprep;
	for (i = 0;i < NUM_ZUC_EIA3_TESTS; i++)
	{
		memcpy(pKeys,testEIA3_vectors[i].CK, ZUC_KEY_LEN_IN_BYTES);
		IVprep.IVl[0] = IVprep.IVl[1] = 0;
		IVprep.IVw[2] = IVprep.IVw[0] = __builtin_bswap32(testEIA3_vectors[i].count);
		IVprep.IVb[8]  ^= (testEIA3_vectors[i].Direction << 7);
		IVprep.IVb[4] = IVprep.IVb[12] = (testEIA3_vectors[i].Bearer << 3);
		IVprep.IVb[14] ^=  (testEIA3_vectors[i].Direction << 7);

		memcpy(pIV, IVprep.IVb , ZUC_IV_LEN_IN_BYTES);
		byteLength = (testEIA3_vectors[i].length_in_bits +7)/8;
		memcpy(pSrcData, testEIA3_vectors[i].message, byteLength);
		sso_zuc_eia3_1_buffer( pKeys, pIV, pSrcData, testEIA3_vectors[i].length_in_bits, (uint32_t*) pDstData);
		retTmp = memcmp( pDstData, &testEIA3_vectors[i].mac, sizeof(((struct test128EIA3_vectors_t*)0)->mac));
		if (retTmp) {
			printf("Validate ZUC 1 block  test %d (Int): FAIL\n",i+1);
			sso_hexdump("Expected",(uint8_t*) &testEIA3_vectors[i].mac, sizeof(((struct test128EIA3_vectors_t*)0)->mac));
			sso_hexdump("Found", pDstData, sizeof(((struct test128EIA3_vectors_t*)0)->mac));
			ret = retTmp;
			//return ret;
		}  else
				printf("Validate ZUC 1 block  test %d (Int): PASS\n",i+1);
		fflush(stdout);
	}
	return ret;
};
int validate_sso_zuc_algorithm( uint8_t *pSrcData, uint8_t *pDstData, uint8_t *pKeys, uint8_t *pIV){
	uint32_t i, ret = 0;
	union SwapBytes {
		uint8_t sbb[8];
		uint32_t sbw[2];
	} swapBytes;

	for (i = 0;i < NUM_ZUC_ALG_TESTS; i++)
	{
		memcpy(pKeys,testZUC_vectors[i].CK, ZUC_KEY_LEN_IN_BYTES);
		memcpy(pIV, testZUC_vectors[i].IV , ZUC_IV_LEN_IN_BYTES);
		memset(pSrcData, 0, 8);
		sso_zuc_eea3_1_buffer( pKeys, pIV, pSrcData, pDstData, 8);
		swapBytes.sbw[0] = __builtin_bswap32(testZUC_vectors[i].Z[0]);
		swapBytes.sbw[1] = __builtin_bswap32(testZUC_vectors[i].Z[1]);
		ret = memcmp( pDstData, swapBytes.sbb, 8);
		if (ret) {
			printf("ZUC 1 algorithm test %d: FAIL\n",i);
			//return ret;
		} else {
			printf("ZUC 1 algorithm test %d: PASS\n",i);
		}
	}
	return ret;
};
/******************************************************************************$
 ** @description - utility function to dump test buffers$
 ** $
 ** @param message [IN] - debug message to print$
 ** @param ptr [IN] - pointer to beginning of buffer.$
 ** @param len [IN] - length of buffer.$
 *******************************************************************************/
static void sso_hexdump(char* message, const uint8_t *ptr, int len)
{
	int ctr;
	printf("%s: \n", message);
	for (ctr = 0; ctr < len; ctr++) {
		printf("0x%02X ", ptr[ctr] & 0xff);
		if (!((ctr+1) % 16))
			printf("\n");
	}
	printf("\n");
	printf("\n");
};
